package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.FindInPage
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.FindInPage
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.di.AppContainer
import com.example.ui.components.HairlineDivider
import com.example.ui.screens.apps.AppsScreen
import com.example.ui.screens.apps.AppsViewModel
import com.example.ui.screens.battery.BatteryScreen
import com.example.ui.screens.battery.BatteryViewModel
import com.example.ui.screens.cleaner.CleanerScreen
import com.example.ui.screens.cleaner.CleanerViewModel
import com.example.ui.screens.scanner.ScannerScreen
import com.example.ui.screens.scanner.ScannerViewModel

sealed class DeviceHealthDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    data object Scanner : DeviceHealthDestination(
        route = "scanner",
        labelRes = R.string.nav_scanner,
        selectedIcon = Icons.Filled.FindInPage,
        unselectedIcon = Icons.Outlined.FindInPage,
        testTag = "nav_tab_scanner"
    )

    data object Cleaner : DeviceHealthDestination(
        route = "cleaner",
        labelRes = R.string.nav_cleaner,
        selectedIcon = Icons.Filled.CleaningServices,
        unselectedIcon = Icons.Outlined.CleaningServices,
        testTag = "nav_tab_cleaner"
    )

    data object Battery : DeviceHealthDestination(
        route = "battery",
        labelRes = R.string.nav_battery,
        selectedIcon = Icons.Filled.BatteryChargingFull,
        unselectedIcon = Icons.Outlined.BatteryChargingFull,
        testTag = "nav_tab_battery"
    )

    data object Apps : DeviceHealthDestination(
        route = "apps",
        labelRes = R.string.nav_apps,
        selectedIcon = Icons.Filled.Apps,
        unselectedIcon = Icons.Outlined.Apps,
        testTag = "nav_tab_apps"
    )

    companion object {
        val entries = listOf(Scanner, Cleaner, Battery, Apps)
    }
}

@Composable
fun DeviceHealthApp(
    container: AppContainer
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val scannerViewModel: ScannerViewModel = viewModel(
        factory = ScannerViewModel.factory(
            scanStorageUseCase = container.scanStorageUseCase,
            deleteScannedFilesUseCase = container.deleteScannedFilesUseCase,
            cacheCleanerRepository = container.cacheCleanerRepository
        )
    )
    val cleanerViewModel: CleanerViewModel = viewModel(
        factory = CleanerViewModel.factory(container.cacheCleanerRepository)
    )
    val batteryViewModel: BatteryViewModel = viewModel(
        factory = BatteryViewModel.factory(
            observeBatteryHealthUseCase = container.observeBatteryHealthUseCase,
            batteryRepository = container.batteryRepository
        )
    )
    val appsViewModel: AppsViewModel = viewModel(
        factory = AppsViewModel.factory(
            loadInstalledAppsUseCase = container.loadInstalledAppsUseCase,
            repository = container.appManagerRepository
        )
    )

    fun navigateToTab(destination: DeviceHealthDestination) {
        navController.navigate(destination.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 840.dp

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets.statusBars,
            bottomBar = {
                if (!useNavigationRail) {
                    androidx.compose.foundation.layout.Column {
                        HairlineDivider()
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 0.dp,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            DeviceHealthDestination.entries.forEach { destination ->
                                val selected = currentDestination?.hierarchy?.any {
                                    it.route == destination.route
                                } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(destination) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                            contentDescription = stringResource(destination.labelRes)
                                        )
                                    },
                                    label = { Text(stringResource(destination.labelRes)) },
                                    modifier = Modifier.testTag(destination.testTag)
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        DeviceHealthDestination.entries.forEach { destination ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.route == destination.route
                            } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTab(destination) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) destination.selectedIcon else destination.unselectedIcon,
                                        contentDescription = stringResource(destination.labelRes)
                                    )
                                },
                                label = { Text(stringResource(destination.labelRes)) },
                                modifier = Modifier.testTag(destination.testTag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = DeviceHealthDestination.Scanner.route,
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 760.dp)
                    ) {
                        composable(DeviceHealthDestination.Scanner.route) {
                            ScannerScreen(viewModel = scannerViewModel)
                        }
                        composable(DeviceHealthDestination.Cleaner.route) {
                            CleanerScreen(viewModel = cleanerViewModel)
                        }
                        composable(DeviceHealthDestination.Battery.route) {
                            BatteryScreen(viewModel = batteryViewModel)
                        }
                        composable(DeviceHealthDestination.Apps.route) {
                            AppsScreen(viewModel = appsViewModel)
                        }
                    }
                }
            }
        }
    }
}
