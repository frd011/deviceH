package com.example.ui.screens.cleaner

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.CleanerOverview
import com.example.domain.repository.CacheCleanerRepository
import com.example.util.FormatUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CleanerUiState(
    val isLoading: Boolean = true,
    val overview: CleanerOverview? = null,
    val selectedTargetIds: Set<String> = emptySet(),
    val isCleaning: Boolean = false,
    val showCleanConfirmation: Boolean = false,
    val showPermissionOnboarding: Boolean = false,
    val lastCleanSummary: String? = null
) {
    val selectedBytes: Long
        get() = overview?.targets
            ?.filter { it.id in selectedTargetIds }
            ?.sumOf { it.sizeBytes }
            ?: 0L

    val selectedItemCount: Int
        get() = overview?.targets
            ?.filter { it.id in selectedTargetIds }
            ?.sumOf { it.itemCount }
            ?: 0
}

class CleanerViewModel(
    private val repository: CacheCleanerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CleanerUiState())
    val uiState: StateFlow<CleanerUiState> = _uiState.asStateFlow()

    init {
        refreshOverview()
    }

    fun refreshOverview() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val overview = repository.analyzeCleanerOverview()
            _uiState.update { state ->
                state.copy(
                    isLoading = false,
                    overview = overview,
                    selectedTargetIds = overview.targets.map { it.id }.toSet()
                )
            }
        }
    }

    fun toggleTarget(targetId: String) {
        _uiState.update { state ->
            val updated = if (targetId in state.selectedTargetIds) {
                state.selectedTargetIds - targetId
            } else {
                state.selectedTargetIds + targetId
            }
            state.copy(selectedTargetIds = updated)
        }
    }

    fun openCleanConfirmation() {
        if (_uiState.value.selectedTargetIds.isNotEmpty()) {
            _uiState.update { it.copy(showCleanConfirmation = true) }
        }
    }

    fun dismissCleanConfirmation() {
        _uiState.update { it.copy(showCleanConfirmation = false) }
    }

    fun cleanSelectedTargets() {
        val currentOverview = _uiState.value.overview ?: return
        val selected = currentOverview.targets.filter { it.id in _uiState.value.selectedTargetIds }
        if (selected.isEmpty()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isCleaning = true) }
            val result = repository.cleanTargets(selected)
            val updatedOverview = repository.analyzeCleanerOverview()
            _uiState.update { state ->
                state.copy(
                    isCleaning = false,
                    showCleanConfirmation = false,
                    overview = updatedOverview,
                    selectedTargetIds = updatedOverview.targets.map { it.id }.toSet(),
                    lastCleanSummary = "Cleared ${FormatUtils.formatBytes(result.freedBytes)} across ${result.deletedCount} items"
                )
            }
        }
    }

    fun onSafFolderGranted(uri: Uri) {
        viewModelScope.launch {
            repository.persistSafTreeUri(uri)
            refreshOverview()
        }
    }

    fun removeSafFolder(uriString: String) {
        viewModelScope.launch {
            repository.removeSafTreeUri(Uri.parse(uriString))
            refreshOverview()
        }
    }

    fun markAppCacheReviewed(packageName: String) {
        viewModelScope.launch {
            repository.markAppCacheReviewed(packageName)
            refreshOverview()
        }
    }

    fun setPermissionOnboardingVisible(visible: Boolean) {
        _uiState.update { it.copy(showPermissionOnboarding = visible) }
    }

    fun clearCleanSummary() {
        _uiState.update { it.copy(lastCleanSummary = null) }
    }

    companion object {
        fun factory(repository: CacheCleanerRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return CleanerViewModel(repository) as T
                }
            }
    }
}
