package com.example.ui.screens.battery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.BatteryStatusSnapshot
import com.example.domain.repository.BatteryRepository
import com.example.domain.usecase.ObserveBatteryHealthUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class BatteryViewModel(
    observeBatteryHealthUseCase: ObserveBatteryHealthUseCase,
    private val batteryRepository: BatteryRepository
) : ViewModel() {

    private val _currentSamplesMa = MutableStateFlow<List<Int>>(emptyList())
    val currentSamplesMa: StateFlow<List<Int>> = _currentSamplesMa.asStateFlow()

    val snapshot: StateFlow<BatteryStatusSnapshot?> = observeBatteryHealthUseCase()
        .onEach { snap ->
            _currentSamplesMa.update { list ->
                (list + snap.currentNowMa).takeLast(24)
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = null
        )

    private val _showDesignCapacityDialog = MutableStateFlow(false)
    val showDesignCapacityDialog: StateFlow<Boolean> = _showDesignCapacityDialog.asStateFlow()

    fun setDesignCapacityDialogVisible(visible: Boolean) {
        _showDesignCapacityDialog.value = visible
    }

    fun updateCustomDesignCapacity(capacityMah: Int?) {
        viewModelScope.launch {
            batteryRepository.setCustomDesignCapacityMah(capacityMah)
            _showDesignCapacityDialog.value = false
        }
    }

    fun clearSessionHistory() {
        viewModelScope.launch {
            batteryRepository.clearSessionHistory()
        }
    }

    companion object {
        fun factory(
            observeBatteryHealthUseCase: ObserveBatteryHealthUseCase,
            batteryRepository: BatteryRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return BatteryViewModel(observeBatteryHealthUseCase, batteryRepository) as T
            }
        }
    }
}
