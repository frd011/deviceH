package com.example.ui.screens.apps

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.AppCategoryFilter
import com.example.domain.model.AppSortOption
import com.example.domain.model.InstalledAppInfo
import com.example.domain.repository.AppManagerRepository
import com.example.domain.usecase.LoadInstalledAppsUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AppsUiState(
    val isLoading: Boolean = true,
    val hasUsageAccess: Boolean = false,
    val allApps: List<InstalledAppInfo> = emptyList(),
    val filteredApps: List<InstalledAppInfo> = emptyList(),
    val sortOption: AppSortOption = AppSortOption.TOTAL_SIZE,
    val categoryFilter: AppCategoryFilter = AppCategoryFilter.USER,
    val searchQuery: String = "",
    val selectedApp: InstalledAppInfo? = null,
    val totalFootprintBytes: Long = 0L,
    val totalCacheBytes: Long = 0L
)

class AppsViewModel(
    private val loadInstalledAppsUseCase: LoadInstalledAppsUseCase,
    private val repository: AppManagerRepository
) : ViewModel() {

    private val isLoading = MutableStateFlow(true)
    private val hasUsageAccess = MutableStateFlow(repository.hasUsageStatsPermission())
    private val allApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    private val sortOption = MutableStateFlow(AppSortOption.TOTAL_SIZE)
    private val categoryFilter = MutableStateFlow(AppCategoryFilter.USER)
    private val searchQuery = MutableStateFlow("")
    private val selectedApp = MutableStateFlow<InstalledAppInfo?>(null)

    private val filterParams = combine(
        sortOption,
        categoryFilter,
        searchQuery
    ) { sort, category, query ->
        Triple(sort, category, query)
    }

    val uiState: StateFlow<AppsUiState> = combine(
        isLoading,
        hasUsageAccess,
        allApps,
        filterParams,
        selectedApp
    ) { loading, usageGranted, apps, (sort, category, query), activeApp ->
        val categoryFiltered = when (category) {
            AppCategoryFilter.USER -> apps.filter { !it.isSystemApp }
            AppCategoryFilter.SYSTEM -> apps.filter { it.isSystemApp }
            AppCategoryFilter.ALL -> apps
        }

        val queryTrimmed = query.trim()
        val searched = if (queryTrimmed.isEmpty()) {
            categoryFiltered
        } else {
            categoryFiltered.filter {
                it.appName.contains(queryTrimmed, ignoreCase = true) ||
                    it.packageName.contains(queryTrimmed, ignoreCase = true)
            }
        }

        val sorted = when (sort) {
            AppSortOption.TOTAL_SIZE -> searched.sortedByDescending { it.totalBytes }
            AppSortOption.CACHE_SIZE -> searched.sortedByDescending { it.cacheBytes }
            AppSortOption.LAST_USED -> searched.sortedByDescending { it.lastUsedMs }
            AppSortOption.NAME -> searched.sortedBy { it.appName.lowercase() }
        }

        AppsUiState(
            isLoading = loading,
            hasUsageAccess = usageGranted,
            allApps = apps,
            filteredApps = sorted,
            sortOption = sort,
            categoryFilter = category,
            searchQuery = query,
            selectedApp = activeApp,
            totalFootprintBytes = sorted.sumOf { it.totalBytes },
            totalCacheBytes = sorted.sumOf { it.cacheBytes }
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AppsUiState()
    )

    init {
        refreshApps()
    }

    fun refreshApps() {
        viewModelScope.launch {
            isLoading.value = true
            hasUsageAccess.value = repository.hasUsageStatsPermission()
            allApps.value = loadInstalledAppsUseCase()
            isLoading.value = false
        }
    }

    fun setSortOption(option: AppSortOption) {
        sortOption.value = option
    }

    fun setCategoryFilter(filter: AppCategoryFilter) {
        categoryFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun selectApp(app: InstalledAppInfo?) {
        selectedApp.value = app
    }

    companion object {
        fun factory(
            loadInstalledAppsUseCase: LoadInstalledAppsUseCase,
            repository: AppManagerRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return AppsViewModel(loadInstalledAppsUseCase, repository) as T
            }
        }
    }
}
