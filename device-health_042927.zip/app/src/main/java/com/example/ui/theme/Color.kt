package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Light mode neutral slate surfaces
val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF1F5)
val LightSurfaceContainerLow = Color(0xFFF2F4F8)
val LightSurfaceContainerHigh = Color(0xFFE6EAF0)
val LightOutline = Color(0xFFD5DBE3)
val LightOutlineVariant = Color(0xFFE3E7EE)
val LightOnSurface = Color(0xFF12151A)
val LightOnSurfaceVariant = Color(0xFF5A6372)
val LightPrimary = Color(0xFF0F766E)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFD7F3EE)
val LightOnPrimaryContainer = Color(0xFF073B37)

// Dark mode deep charcoal surfaces (#121316 anchor)
val DarkBackground = Color(0xFF121316)
val DarkSurface = Color(0xFF191B20)
val DarkSurfaceVariant = Color(0xFF23262E)
val DarkSurfaceContainerLow = Color(0xFF16181C)
val DarkSurfaceContainerHigh = Color(0xFF282B34)
val DarkOutline = Color(0xFF343944)
val DarkOutlineVariant = Color(0xFF282C35)
val DarkOnSurface = Color(0xFFF1F3F6)
val DarkOnSurfaceVariant = Color(0xFF9AA3B2)
val DarkPrimary = Color(0xFF34D399)
val DarkOnPrimary = Color(0xFF062E22)
val DarkPrimaryContainer = Color(0xFF143B31)
val DarkOnPrimaryContainer = Color(0xFFA7F3D0)

// Purposeful Semantic Status Tokens (Muted Emerald, Warm Amber, Soft Coral)
@Immutable
data class StatusColors(
    val healthy: Color,
    val healthyContainer: Color,
    val onHealthyContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val onWarningContainer: Color,
    val critical: Color,
    val criticalContainer: Color,
    val onCriticalContainer: Color,
    val info: Color,
    val infoContainer: Color,
    val onInfoContainer: Color,
    val hairline: Color
)

val LightStatusColors = StatusColors(
    healthy = Color(0xFF059669),
    healthyContainer = Color(0xFFE6F7F1),
    onHealthyContainer = Color(0xFF064E3B),
    warning = Color(0xFFD97706),
    warningContainer = Color(0xFFFEF5E6),
    onWarningContainer = Color(0xFF78350F),
    critical = Color(0xFFE11D48),
    criticalContainer = Color(0xFFFDECEF),
    onCriticalContainer = Color(0xFF881337),
    info = Color(0xFF0284C7),
    infoContainer = Color(0xFFE8F4FC),
    onInfoContainer = Color(0xFF0C4A6E),
    hairline = LightOutlineVariant
)

val DarkStatusColors = StatusColors(
    healthy = Color(0xFF34D399),
    healthyContainer = Color(0xFF122C24),
    onHealthyContainer = Color(0xFFA7F3D0),
    warning = Color(0xFFFBBF24),
    warningContainer = Color(0xFF2C2312),
    onWarningContainer = Color(0xFFFDE68A),
    critical = Color(0xFFFB7185),
    criticalContainer = Color(0xFF2F161D),
    onCriticalContainer = Color(0xFFFECDD3),
    info = Color(0xFF38BDF8),
    infoContainer = Color(0xFF132736),
    onInfoContainer = Color(0xFFBAE6FD),
    hairline = DarkOutlineVariant
)

val LocalStatusColors = staticCompositionLocalOf { LightStatusColors }
