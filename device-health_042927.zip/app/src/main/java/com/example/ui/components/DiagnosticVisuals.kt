package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalStatusColors
import com.example.ui.theme.TabularBodyValue
import com.example.ui.theme.TabularCaptionValue
import com.example.ui.theme.TabularDisplayMetric
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

data class StorageSegment(
    val label: String,
    val bytes: Long,
    val color: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SegmentedStorageBar(
    segments: List<StorageSegment>,
    totalReferenceBytes: Long,
    modifier: Modifier = Modifier
) {
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val safeTotal = totalReferenceBytes.coerceAtLeast(1L)

    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
        ) {
            drawRoundRect(
                color = trackColor,
                size = size,
                cornerRadius = CornerRadius(size.height / 2f, size.height / 2f)
            )
            var currentX = 0f
            val gapPx = 2.dp.toPx()
            val nonZero = segments.filter { it.bytes > 0L }
            nonZero.forEachIndexed { index, seg ->
                val rawWidth = (seg.bytes.toFloat() / safeTotal.toFloat()) * size.width
                val segWidth = if (index == nonZero.lastIndex) {
                    (size.width - currentX).coerceAtLeast(0f).coerceAtMost(rawWidth.coerceAtLeast(4.dp.toPx()))
                } else {
                    (rawWidth - gapPx).coerceAtLeast(3.dp.toPx())
                }
                if (currentX < size.width && segWidth > 0f) {
                    drawRoundRect(
                        color = seg.color,
                        topLeft = Offset(currentX, 0f),
                        size = Size(segWidth.coerceAtMost(size.width - currentX), size.height),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )
                    currentX += segWidth + gapPx
                }
            }
        }

        val visibleLegend = segments.filter { it.bytes > 0L }
        if (visibleLegend.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                visibleLegend.forEach { seg ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(seg.color, CircleShape)
                        )
                        Text(
                            text = seg.label,
                            style = TabularCaptionValue,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PrecisionArcGauge(
    progress: Float,
    centerTitle: String,
    centerSubtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    size: Dp = 132.dp,
    strokeWidth: Dp = 11.dp
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 650),
        label = "arcProgress"
    )
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val tickColor = LocalStatusColors.current.hairline

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val strokePx = strokeWidth.toPx()
            val inset = strokePx / 2f + 6.dp.toPx()
            val arcSize = Size(this.size.width - inset * 2f, this.size.height - inset * 2f)
            val topLeft = Offset(inset, inset)
            val startAngle = 140f
            val sweepTotal = 260f

            // Subtle outer tick marks
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val outerR = this.size.minDimension / 2f - 1.dp.toPx()
            val innerR = outerR - 3.dp.toPx()
            for (i in 0..20) {
                val angleDeg = startAngle + (sweepTotal * (i / 20f))
                val rad = Math.toRadians(angleDeg.toDouble())
                val start = Offset(
                    center.x + (innerR * cos(rad)).toFloat(),
                    center.y + (innerR * sin(rad)).toFloat()
                )
                val end = Offset(
                    center.x + (outerR * cos(rad)).toFloat(),
                    center.y + (outerR * sin(rad)).toFloat()
                )
                drawLine(
                    color = tickColor,
                    start = start,
                    end = end,
                    strokeWidth = if (i % 5 == 0) 1.5.dp.toPx() else 1.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Track arc
            drawArc(
                color = trackColor,
                startAngle = startAngle,
                sweepAngle = sweepTotal,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Active value arc
            if (animatedProgress > 0f) {
                drawArc(
                    color = accentColor,
                    startAngle = startAngle,
                    sweepAngle = sweepTotal * animatedProgress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokePx, cap = StrokeCap.Round)
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerTitle,
                style = TabularDisplayMetric,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = centerSubtitle,
                style = TabularCaptionValue,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun LiveCurrentSparkline(
    samplesMa: List<Int>,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val gridColor = LocalStatusColors.current.hairline
    val values = if (samplesMa.size >= 2) {
        samplesMa.map { abs(it).toFloat() }
    } else {
        val single = samplesMa.firstOrNull()?.let { abs(it).toFloat() } ?: 0f
        listOf(single, single)
    }

    val maxVal = (values.maxOrNull() ?: 100f).coerceAtLeast(100f)
    val minVal = (values.minOrNull() ?: 0f).coerceAtMost(maxVal * 0.7f)
    val span = (maxVal - minVal).coerceAtLeast(50f)

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
    ) {
        val w = size.width
        val h = size.height
        val padTop = 6.dp.toPx()
        val padBottom = 4.dp.toPx()
        val usableH = (h - padTop - padBottom).coerceAtLeast(1f)

        // Subtle baseline & mid hairline
        drawLine(
            color = gridColor,
            start = Offset(0f, h - padBottom),
            end = Offset(w, h - padBottom),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = gridColor.copy(alpha = 0.5f),
            start = Offset(0f, padTop + usableH / 2f),
            end = Offset(w, padTop + usableH / 2f),
            strokeWidth = 1.dp.toPx()
        )

        val stepX = if (values.size > 1) w / (values.size - 1).toFloat() else w
        val linePath = Path()
        val fillPath = Path()

        values.forEachIndexed { idx, v ->
            val x = idx * stepX
            val normalized = ((v - minVal) / span).coerceIn(0f, 1f)
            val y = padTop + usableH * (1f - normalized)
            if (idx == 0) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, h - padBottom)
                fillPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            if (idx == values.lastIndex) {
                fillPath.lineTo(x, h - padBottom)
                fillPath.close()
            }
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    accentColor.copy(alpha = 0.22f),
                    accentColor.copy(alpha = 0.0f)
                )
            )
        )
        drawPath(
            path = linePath,
            color = accentColor,
            style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
        )

        // Live trailing dot
        val lastNorm = ((values.last() - minVal) / span).coerceIn(0f, 1f)
        val lastY = padTop + usableH * (1f - lastNorm)
        drawCircle(
            color = accentColor,
            radius = 3.5.dp.toPx(),
            center = Offset(w, lastY)
        )
    }
}

@Composable
fun CompactIconBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    containerColor: Color,
    iconTint: Color,
    modifier: Modifier = Modifier,
    boxSize: Dp = 32.dp
) {
    Box(
        modifier = modifier
            .size(boxSize)
            .clip(RoundedCornerShape(9.dp))
            .background(containerColor),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(boxSize * 0.56f)
        )
    }
}

@Composable
fun StorageRatioHeaderRow(
    usedBytes: Long,
    totalBytes: Long,
    label: String,
    valueText: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = valueText,
            style = TabularBodyValue,
            color = accentColor
        )
    }
}
