package com.example.ui.screens.cleaner

import android.Manifest
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.BrokenImage
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.FolderDelete
import androidx.compose.material.icons.outlined.FolderSpecial
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.domain.model.AppCacheGuideItem
import com.example.domain.model.CleanableTarget
import com.example.domain.model.CleanableTargetType
import com.example.domain.model.StorageAccessMode
import com.example.ui.components.CompactIconBadge
import com.example.ui.components.EmptyStateBlock
import com.example.ui.components.HairlineDivider
import com.example.ui.components.PrecisionArcGauge
import com.example.ui.components.SectionHeaderRow
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.TactileSurfaceCard
import com.example.ui.theme.LocalStatusColors
import com.example.ui.theme.TabularBodyValue
import com.example.ui.theme.TabularCaptionValue
import com.example.ui.theme.TabularCardMetric
import com.example.util.FormatUtils
import com.example.util.StoragePermissionUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CleanerScreen(
    viewModel: CleanerViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val statusColors = LocalStatusColors.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshOverview()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshOverview()
    }

    val allFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshOverview()
    }

    val safTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            viewModel.onSafFolderGranted(uri)
        }
    }

    val storageStats = remember(uiState.overview) {
        try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val total = stat.totalBytes.coerceAtLeast(1L)
            val free = stat.availableBytes.coerceAtLeast(0L)
            val used = (total - free).coerceAtLeast(0L)
            Triple(used, free, total)
        } catch (_: Exception) {
            Triple(0L, 0L, 1L)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = stringResource(R.string.cleaner_title),
                    style = MaterialTheme.typography.headlineSmall
                )
                StatusBadgePill(
                    text = "API ${Build.VERSION.SDK_INT}",
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(
                onClick = { viewModel.refreshOverview() },
                modifier = Modifier.testTag("cleaner_refresh_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Refresh,
                    contentDescription = "Refresh cleaner analysis"
                )
            }
        }

        if (uiState.isLoading) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            )
        }

        AnimatedVisibility(visible = uiState.lastCleanSummary != null) {
            uiState.lastCleanSummary?.let { summary ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp),
                    shape = MaterialTheme.shapes.small,
                    color = statusColors.healthyContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = statusColors.onHealthyContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearCleanSummary() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Dismiss summary",
                                tint = statusColors.onHealthyContainer,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        val overview = uiState.overview
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (overview != null) {
                // Visual Storage Gauge Hero Card
                item(key = "storage_hero_card") {
                    val (usedBytes, freeBytes, totalBytes) = storageStats
                    val usedRatio = (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
                    val usedPercent = (usedRatio * 100).toInt()
                    val gaugeColor = when {
                        usedRatio >= 0.90f -> statusColors.critical
                        usedRatio >= 0.78f -> statusColors.warning
                        else -> MaterialTheme.colorScheme.primary
                    }

                    TactileSurfaceCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            PrecisionArcGauge(
                                progress = usedRatio,
                                centerTitle = "$usedPercent%",
                                centerSubtitle = "USED",
                                accentColor = gaugeColor,
                                size = 116.dp,
                                strokeWidth = 10.dp
                            )
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                StatusBadgePill(
                                    text = when (overview.accessMode) {
                                        StorageAccessMode.FULL_STORAGE_GRANTED -> "Full Storage"
                                        StorageAccessMode.LEGACY_STORAGE_GRANTED -> "Legacy Storage"
                                        StorageAccessMode.SAF_ONLY -> "SAF Mode"
                                        StorageAccessMode.NEEDS_PERMISSION -> "Limited Access"
                                    },
                                    containerColor = when (overview.accessMode) {
                                        StorageAccessMode.FULL_STORAGE_GRANTED,
                                        StorageAccessMode.LEGACY_STORAGE_GRANTED -> statusColors.healthyContainer
                                        StorageAccessMode.SAF_ONLY -> statusColors.infoContainer
                                        StorageAccessMode.NEEDS_PERMISSION -> statusColors.warningContainer
                                    },
                                    contentColor = when (overview.accessMode) {
                                        StorageAccessMode.FULL_STORAGE_GRANTED,
                                        StorageAccessMode.LEGACY_STORAGE_GRANTED -> statusColors.onHealthyContainer
                                        StorageAccessMode.SAF_ONLY -> statusColors.onInfoContainer
                                        StorageAccessMode.NEEDS_PERMISSION -> statusColors.onWarningContainer
                                    }
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Free",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = FormatUtils.formatBytes(freeBytes),
                                        style = TabularBodyValue
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Reclaimable",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = FormatUtils.formatBytes(uiState.selectedBytes),
                                        style = TabularBodyValue,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        if (overview.accessMode == StorageAccessMode.NEEDS_PERMISSION ||
                            overview.accessMode == StorageAccessMode.SAF_ONLY
                        ) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { viewModel.setPermissionOnboardingVisible(true) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("cleaner_onboarding_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Security,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Full Access")
                                }
                                OutlinedButton(
                                    onClick = {
                                        safTreeLauncher.launch(
                                            StoragePermissionUtils.buildInitialSafAndroidDataUri()
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("cleaner_link_saf_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.CreateNewFolder,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("SAF Folder")
                                }
                            }
                        }
                    }
                }

                // Reclaimable Targets
                item(key = "targets_header") {
                    SectionHeaderRow(
                        title = "CLEANABLE TARGETS",
                        trailing = FormatUtils.formatBytes(uiState.selectedBytes)
                    )
                }

                if (overview.targets.isEmpty()) {
                    item(key = "no_targets") {
                        TactileSurfaceCard(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                            EmptyStateBlock(
                                icon = Icons.Outlined.CheckCircle,
                                title = "No Residual Junk Found",
                                description = if (overview.accessMode == StorageAccessMode.NEEDS_PERMISSION) {
                                    "Grant access or link a folder via SAF"
                                } else {
                                    "Storage caches are clean"
                                }
                            )
                        }
                    }
                } else {
                    items(
                        items = overview.targets,
                        key = { it.id }
                    ) { target ->
                        CleanableTargetRow(
                            target = target,
                            selected = target.id in uiState.selectedTargetIds,
                            onToggle = { viewModel.toggleTarget(target.id) }
                        )
                    }

                    item(key = "clean_action_button") {
                        Button(
                            onClick = { viewModel.openCleanConfirmation() },
                            enabled = uiState.selectedTargetIds.isNotEmpty() && !uiState.isCleaning,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("cleaner_execute_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CleaningServices,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Clean Selected (${FormatUtils.formatBytes(uiState.selectedBytes)})"
                            )
                        }
                    }
                }

                // Scoped Folders (SAF)
                item(key = "saf_header") {
                    Spacer(modifier = Modifier.height(4.dp))
                    SectionHeaderRow(
                        title = "SCOPED FOLDERS (SAF)",
                        trailing = "${overview.safLocations.size} linked"
                    )
                }

                item(key = "saf_card") {
                    TactileSurfaceCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                CompactIconBadge(
                                    icon = Icons.Outlined.FolderSpecial,
                                    containerColor = statusColors.infoContainer,
                                    iconTint = statusColors.onInfoContainer
                                )
                                Text(
                                    text = "SAF Tree Folders",
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    safTreeLauncher.launch(
                                        StoragePermissionUtils.buildInitialSafAndroidDataUri()
                                    )
                                },
                                modifier = Modifier.testTag("cleaner_add_saf_folder_button")
                            ) {
                                Text("Add")
                            }
                        }

                        if (overview.safLocations.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            HairlineDivider()
                            overview.safLocations.forEach { loc ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = loc.displayName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${loc.cacheCandidateCount} items · ${FormatUtils.formatBytes(loc.cacheBytes)}",
                                            style = TabularCaptionValue,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    TextButton(onClick = { viewModel.removeSafFolder(loc.treeUri) }) {
                                        Text("Unlink")
                                    }
                                }
                            }
                        }
                    }
                }

                // Guided App Cache Helper
                item(key = "guided_cache_header") {
                    Spacer(modifier = Modifier.height(4.dp))
                    SectionHeaderRow(
                        title = "APP CACHES",
                        trailing = if (overview.hasUsageStatsAccess) "By size" else null
                    )
                }

                if (!overview.hasUsageStatsAccess) {
                    item(key = "usage_stats_hint") {
                        TactileSurfaceCard(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Enable Usage Access for cache sizes",
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = {
                                        context.startActivity(
                                            StoragePermissionUtils.buildUsageAccessIntent(context)
                                        )
                                    },
                                    modifier = Modifier.testTag("cleaner_usage_access_button")
                                ) {
                                    Text("Enable")
                                }
                            }
                        }
                    }
                }

                items(
                    items = overview.appCacheGuides,
                    key = { "guide_${it.packageName}" }
                ) { guide ->
                    AppCacheGuideRow(
                        item = guide,
                        onOpenSettings = {
                            viewModel.markAppCacheReviewed(guide.packageName)
                            context.startActivity(
                                StoragePermissionUtils.buildAppDetailsIntent(guide.packageName)
                            )
                        }
                    )
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // All Files Access Onboarding Sheet
    if (uiState.showPermissionOnboarding) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.setPermissionOnboardingVisible(false) },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            "All Files Access"
                        } else {
                            "Storage Permission"
                        },
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Required locally to clean .thumbnails, residual logs, and empty directories.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.setPermissionOnboardingVisible(false) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(stringResource(R.string.action_cancel))
                    }
                    Button(
                        onClick = {
                            viewModel.setPermissionOnboardingVisible(false)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                allFilesLauncher.launch(
                                    StoragePermissionUtils.buildAllFilesAccessIntent(context)
                                )
                            } else {
                                legacyPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.READ_EXTERNAL_STORAGE,
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                                    )
                                )
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cleaner_confirm_onboarding_button")
                    ) {
                        Text("Allow")
                    }
                }
            }
        }
    }

    // Confirm Clean Sheet
    if (uiState.showCleanConfirmation) {
        ModalBottomSheet(
            onDismissRequest = { if (!uiState.isCleaning) viewModel.dismissCleanConfirmation() },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Text(
                    text = "Confirm Cleanup",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(14.dp))
                TactileSurfaceCard(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RECLAIMABLE SPACE",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = FormatUtils.formatBytes(uiState.selectedBytes),
                                style = TabularCardMetric,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = "${uiState.selectedItemCount} items",
                            style = TabularBodyValue
                        )
                    }
                }
                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.dismissCleanConfirmation() },
                        enabled = !uiState.isCleaning,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(stringResource(R.string.action_cancel))
                    }
                    Button(
                        onClick = { viewModel.cleanSelectedTargets() },
                        enabled = !uiState.isCleaning,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cleaner_confirm_clean_button")
                    ) {
                        Text(if (uiState.isCleaning) "Cleaning..." else "Clean Now")
                    }
                }
            }
        }
    }
}

@Composable
private fun CleanableTargetRow(
    target: CleanableTarget,
    selected: Boolean,
    onToggle: () -> Unit
) {
    val statusColors = LocalStatusColors.current
    val (icon, bg, fg) = when (target.type) {
        CleanableTargetType.HIDDEN_THUMBNAILS -> Triple(
            Icons.Outlined.PhotoLibrary,
            statusColors.warningContainer,
            statusColors.onWarningContainer
        )
        CleanableTargetType.TEMP_AND_LOGS -> Triple(
            Icons.Outlined.BrokenImage,
            statusColors.criticalContainer,
            statusColors.onCriticalContainer
        )
        CleanableTargetType.EMPTY_DIRECTORIES -> Triple(
            Icons.Outlined.FolderDelete,
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.onSurfaceVariant
        )
        CleanableTargetType.SAF_CACHE_FOLDER -> Triple(
            Icons.Outlined.FolderSpecial,
            statusColors.infoContainer,
            statusColors.onInfoContainer
        )
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .testTag("clean_target_${target.id}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else statusColors.hairline
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = selected,
                onCheckedChange = { onToggle() }
            )
            CompactIconBadge(
                icon = icon,
                containerColor = bg,
                iconTint = fg,
                boxSize = 36.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = target.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${target.itemCount} items",
                    style = TabularCaptionValue,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (target.sizeBytes > 0L) FormatUtils.formatBytes(target.sizeBytes) else "0 B",
                style = TabularBodyValue,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
    }
}

@Composable
private fun AppCacheGuideRow(
    item: AppCacheGuideItem,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val statusColors = LocalStatusColors.current
    val iconDrawable by produceState<Drawable?>(initialValue = null, item.packageName) {
        value = withContext(Dispatchers.IO) {
            try {
                context.packageManager.getApplicationIcon(item.packageName)
            } catch (_: Exception) {
                null
            }
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenSettings)
            .testTag("guided_cache_app_${item.packageName}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, statusColors.hairline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(9.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (iconDrawable != null) {
                        AsyncImage(
                            model = iconDrawable,
                            contentDescription = stringResource(R.string.cd_app_icon),
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Apps,
                            contentDescription = stringResource(R.string.cd_app_icon),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Text(
                    text = item.appName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (item.isMarkedCleared) {
                    StatusBadgePill(
                        text = "Opened",
                        containerColor = statusColors.healthyContainer,
                        contentColor = statusColors.onHealthyContainer
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (item.cacheBytes > 0L) {
                    Text(
                        text = FormatUtils.formatBytes(item.cacheBytes),
                        style = TabularBodyValue,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                    contentDescription = "Open app storage settings",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
