package com.example.ui.screens.scanner

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Android
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.AudioFile
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.domain.model.FormatBreakdown
import com.example.domain.model.MediaCategory
import com.example.domain.model.ScanProgressState
import com.example.domain.model.ScannedFileItem
import com.example.domain.model.StorageAccessMode
import com.example.ui.components.CompactIconBadge
import com.example.ui.components.EmptyStateBlock
import com.example.ui.components.HairlineDivider
import com.example.ui.components.KeyValueDetailRow
import com.example.ui.components.SegmentedStorageBar
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.StorageSegment
import com.example.ui.components.TactileSurfaceCard
import com.example.ui.theme.LocalStatusColors
import com.example.ui.theme.TabularBodyValue
import com.example.ui.theme.TabularCaptionValue
import com.example.ui.theme.TabularCardMetric
import com.example.util.FormatUtils
import com.example.util.StoragePermissionUtils
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val statusColors = LocalStatusColors.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshAccessMode()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshAccessMode()
    }

    val safFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            viewModel.onSafTreeSelected(uri)
        }
    }

    val allFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshAccessMode()
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = stringResource(R.string.scanner_title),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { safFolderLauncher.launch(null) },
                    modifier = Modifier.testTag("scanner_saf_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = stringResource(R.string.action_pick_folder)
                    )
                }

                if (uiState.scanState is ScanProgressState.Scanning) {
                    OutlinedButton(
                        onClick = { viewModel.stopScan() },
                        modifier = Modifier.testTag("scanner_stop_button")
                    ) {
                        Text(stringResource(R.string.action_stop_scan))
                    }
                } else {
                    Button(
                        onClick = { viewModel.startScan() },
                        modifier = Modifier.testTag("scanner_start_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            if (uiState.scanState is ScanProgressState.Completed) {
                                stringResource(R.string.action_rescan)
                            } else {
                                "Scan"
                            }
                        )
                    }
                }
            }
        }

        AnimatedVisibility(visible = uiState.statusMessage != null) {
            uiState.statusMessage?.let { msg ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 4.dp),
                    shape = MaterialTheme.shapes.small,
                    color = statusColors.healthyContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            color = statusColors.onHealthyContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { viewModel.clearStatusMessage() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Dismiss message",
                                tint = statusColors.onHealthyContainer,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(visible = uiState.selectedFileIds.isNotEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, statusColors.hairline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "${uiState.selectedFileIds.size} selected",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = FormatUtils.formatBytes(uiState.selectedTotalBytes),
                            style = TabularBodyValue,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { viewModel.selectAllFiltered() },
                            modifier = Modifier.testTag("scanner_select_all_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.SelectAll,
                                contentDescription = "Select all filtered files"
                            )
                        }
                        IconButton(
                            onClick = { viewModel.clearSelection() },
                            modifier = Modifier.testTag("scanner_clear_selection_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Close,
                                contentDescription = "Clear selection"
                            )
                        }
                        Button(
                            onClick = { viewModel.openDeleteConfirmation() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = statusColors.critical,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag("scanner_batch_delete_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.action_delete))
                        }
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (uiState.accessMode == StorageAccessMode.NEEDS_PERMISSION) {
                item(key = "permission_banner") {
                    TactileSurfaceCard {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CompactIconBadge(
                                icon = Icons.Outlined.Security,
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                iconTint = MaterialTheme.colorScheme.onPrimaryContainer,
                                boxSize = 38.dp
                            )
                            Text(
                                text = "Storage Access Required",
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                        allFilesLauncher.launch(
                                            StoragePermissionUtils.buildAllFilesAccessIntent(context)
                                        )
                                    } else {
                                        legacyPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                                            )
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("scanner_grant_access_button")
                            ) {
                                Text(stringResource(R.string.action_grant_access))
                            }
                            OutlinedButton(
                                onClick = { safFolderLauncher.launch(null) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("scanner_onboarding_saf_button")
                            ) {
                                Text("SAF Folder")
                            }
                        }
                    }
                }
            }

            when (val scan = uiState.scanState) {
                is ScanProgressState.Idle -> {
                    item(key = "idle_state") {
                        EmptyStateBlock(
                            icon = Icons.Outlined.Search,
                            title = "Ready to Scan",
                            description = "Inspect hidden dot-files and binary file headers",
                            action = {
                                Button(
                                    onClick = { viewModel.startScan() },
                                    modifier = Modifier.testTag("scanner_idle_start_button")
                                ) {
                                    Text(stringResource(R.string.action_scan_now))
                                }
                            }
                        )
                    }
                }

                is ScanProgressState.Scanning -> {
                    item(key = "scanning_progress") {
                        TactileSurfaceCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "/${scan.currentDirectory}",
                                    style = TabularBodyValue,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = FormatUtils.formatBytes(scan.scannedBytes),
                                    style = TabularBodyValue,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatusBadgePill(
                                    text = "${FormatUtils.formatCount(scan.scannedFilesCount)} files",
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = MaterialTheme.colorScheme.onSurface
                                )
                                StatusBadgePill(
                                    text = "${FormatUtils.formatCount(scan.hiddenFilesCount)} hidden",
                                    containerColor = statusColors.warningContainer,
                                    contentColor = statusColors.onWarningContainer
                                )
                                StatusBadgePill(
                                    text = "${FormatUtils.formatCount(scan.obfuscatedCount)} altered",
                                    containerColor = statusColors.criticalContainer,
                                    contentColor = statusColors.onCriticalContainer
                                )
                            }
                        }
                    }
                }

                is ScanProgressState.Error -> {
                    item(key = "error_state") {
                        TactileSurfaceCard {
                            Text(
                                text = scan.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = statusColors.critical
                            )
                        }
                    }
                }

                is ScanProgressState.Completed -> {
                    item(key = "summary_card") {
                        TactileSurfaceCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                MetricColumn(
                                    label = "TOTAL",
                                    value = FormatUtils.formatBytes(scan.totalBytes)
                                )
                                MetricColumn(
                                    label = "HIDDEN",
                                    value = FormatUtils.formatCount(scan.hiddenCount),
                                    valueColor = if (scan.hiddenCount > 0) statusColors.warning else MaterialTheme.colorScheme.onSurface
                                )
                                MetricColumn(
                                    label = "ALTERED",
                                    value = FormatUtils.formatCount(scan.obfuscatedCount),
                                    valueColor = if (scan.obfuscatedCount > 0) statusColors.critical else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            if (scan.totalBytes > 0L) {
                                Spacer(modifier = Modifier.height(14.dp))
                                val categoryTotals = scan.files.groupBy { it.category }
                                val segments = listOf(
                                    StorageSegment(
                                        label = "Video",
                                        bytes = categoryTotals[MediaCategory.VIDEO]?.sumOf { it.sizeBytes } ?: 0L,
                                        color = MaterialTheme.colorScheme.primary
                                    ),
                                    StorageSegment(
                                        label = "Image",
                                        bytes = categoryTotals[MediaCategory.IMAGE]?.sumOf { it.sizeBytes } ?: 0L,
                                        color = statusColors.info
                                    ),
                                    StorageSegment(
                                        label = "Audio",
                                        bytes = categoryTotals[MediaCategory.AUDIO]?.sumOf { it.sizeBytes } ?: 0L,
                                        color = statusColors.healthy
                                    ),
                                    StorageSegment(
                                        label = "APK",
                                        bytes = categoryTotals[MediaCategory.APK]?.sumOf { it.sizeBytes } ?: 0L,
                                        color = statusColors.warning
                                    ),
                                    StorageSegment(
                                        label = "Archive",
                                        bytes = categoryTotals[MediaCategory.ARCHIVE]?.sumOf { it.sizeBytes } ?: 0L,
                                        color = statusColors.critical
                                    ),
                                    StorageSegment(
                                        label = "Other",
                                        bytes = ((categoryTotals[MediaCategory.DOCUMENT]?.sumOf { it.sizeBytes } ?: 0L) +
                                            (categoryTotals[MediaCategory.OTHER]?.sumOf { it.sizeBytes } ?: 0L)),
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                )
                                SegmentedStorageBar(
                                    segments = segments,
                                    totalReferenceBytes = scan.totalBytes
                                )
                            }
                        }
                    }

                    if (scan.formatBreakdowns.isNotEmpty()) {
                        item(key = "format_breakdown") {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(
                                    items = scan.formatBreakdowns,
                                    key = { it.format.name }
                                ) { breakdown ->
                                    FormatBreakdownChip(
                                        breakdown = breakdown,
                                        selected = uiState.selectedFormat == breakdown.format,
                                        onClick = { viewModel.selectFormat(breakdown.format) }
                                    )
                                }
                            }
                        }
                    }

                    item(key = "filter_bar") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = uiState.hiddenOnly,
                                onClick = { viewModel.toggleHiddenOnly() },
                                label = { Text("Hidden Files Only") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.VisibilityOff,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.testTag("filter_hidden_only_chip")
                            )

                            FilterChip(
                                selected = uiState.obfuscatedOnly,
                                onClick = { viewModel.toggleObfuscatedOnly() },
                                label = { Text("Altered Ext") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.WarningAmber,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.testTag("filter_obfuscated_chip")
                            )

                            listOf(
                                MediaCategory.VIDEO,
                                MediaCategory.IMAGE,
                                MediaCategory.AUDIO,
                                MediaCategory.APK,
                                MediaCategory.ARCHIVE
                            ).forEach { category ->
                                FilterChip(
                                    selected = uiState.selectedCategory == category,
                                    onClick = { viewModel.selectCategory(category) },
                                    label = { Text(category.displayName) }
                                )
                            }
                        }
                    }

                    if (uiState.filteredFiles.isEmpty()) {
                        item(key = "empty_filtered") {
                            EmptyStateBlock(
                                icon = Icons.Outlined.CheckCircle,
                                title = "No Matching Files",
                                description = "Adjust active filters or pick another folder"
                            )
                        }
                    } else {
                        items(
                            items = uiState.filteredFiles,
                            key = { it.id }
                        ) { item ->
                            ScannedFileRow(
                                item = item,
                                isSelected = item.id in uiState.selectedFileIds,
                                inSelectionMode = uiState.selectedFileIds.isNotEmpty(),
                                onClick = {
                                    if (uiState.selectedFileIds.isNotEmpty()) {
                                        viewModel.toggleFileSelection(item.id)
                                    } else {
                                        viewModel.inspectFile(item)
                                    }
                                },
                                onLongClick = { viewModel.toggleFileSelection(item.id) }
                            )
                        }
                    }
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // File Inspection Bottom Sheet
    uiState.inspectedFile?.let { file ->
        ModalBottomSheet(
            onDismissRequest = { viewModel.inspectFile(null) },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FileThumbnailBox(item = file, sizeDp = 48)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = file.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = FormatUtils.formatBytes(file.sizeBytes),
                            style = TabularBodyValue,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusBadgePill(
                        text = file.detectedFormat.label,
                        containerColor = statusColors.infoContainer,
                        contentColor = statusColors.onInfoContainer
                    )
                    if (file.isHidden) {
                        StatusBadgePill(
                            text = if (file.isHiddenDotFile) "Dot-File" else "Hidden Dir",
                            containerColor = statusColors.warningContainer,
                            contentColor = statusColors.onWarningContainer,
                            icon = Icons.Outlined.VisibilityOff
                        )
                    }
                    if (file.isObfuscatedExtension) {
                        StatusBadgePill(
                            text = "Extension Mismatch",
                            containerColor = statusColors.criticalContainer,
                            contentColor = statusColors.onCriticalContainer,
                            icon = Icons.Outlined.WarningAmber
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HairlineDivider()
                KeyValueDetailRow(
                    label = "Declared Ext",
                    value = file.declaredExtension.ifEmpty { "(none)" },
                    monospaceValue = true
                )
                KeyValueDetailRow(
                    label = "Detected Type",
                    value = "${file.detectedFormat.label} (${file.detectedFormat.mimeType})"
                )
                KeyValueDetailRow(
                    label = "Header Bytes",
                    value = file.magicHeaderHex.ifEmpty { "Empty" },
                    monospaceValue = true
                )
                if (file.durationMs != null && file.durationMs > 0L) {
                    KeyValueDetailRow(
                        label = "Duration",
                        value = FormatUtils.formatDurationMs(file.durationMs),
                        monospaceValue = true
                    )
                }
                KeyValueDetailRow(
                    label = "Modified",
                    value = FormatUtils.formatDateTime(file.lastModifiedMs)
                )
                KeyValueDetailRow(
                    label = "Path",
                    value = file.path,
                    monospaceValue = true
                )

                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.inspectFile(null) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Close")
                    }
                    Button(
                        onClick = { viewModel.deleteSingleInspectedFile() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = statusColors.critical,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inspect_sheet_delete_button")
                    ) {
                        Text("Delete File")
                    }
                }
            }
        }
    }

    // Batch Delete Confirmation Bottom Sheet
    if (uiState.showDeleteSheet) {
        ModalBottomSheet(
            onDismissRequest = { if (!uiState.isDeleting) viewModel.dismissDeleteConfirmation() },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Text(
                    text = "Confirm Deletion",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(14.dp))
                TactileSurfaceCard(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SPACE TO BE FREED",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = FormatUtils.formatBytes(uiState.selectedTotalBytes),
                                style = TabularCardMetric,
                                color = statusColors.critical
                            )
                        }
                        Text(
                            text = "${uiState.selectedFileIds.size} files",
                            style = TabularBodyValue,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.dismissDeleteConfirmation() },
                        enabled = !uiState.isDeleting,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(stringResource(R.string.action_cancel))
                    }
                    Button(
                        onClick = { viewModel.deleteSelectedFiles() },
                        enabled = !uiState.isDeleting,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = statusColors.critical,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("confirm_batch_delete_button")
                    ) {
                        Text(if (uiState.isDeleting) "Deleting..." else "Delete")
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricColumn(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface
) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = TabularCardMetric,
            color = valueColor
        )
    }
}

@Composable
private fun FormatBreakdownChip(
    breakdown: FormatBreakdown,
    selected: Boolean,
    onClick: () -> Unit
) {
    val statusColors = LocalStatusColors.current
    Surface(
        onClick = onClick,
        shape = MaterialTheme.shapes.small,
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else statusColors.hairline
        )
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = breakdown.format.label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${breakdown.count}",
                    style = TabularCaptionValue,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = FormatUtils.formatBytes(breakdown.totalBytes),
                style = TabularCaptionValue,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ScannedFileRow(
    item: ScannedFileItem,
    isSelected: Boolean,
    inSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val statusColors = LocalStatusColors.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("scanned_file_row_${item.name}"),
        shape = MaterialTheme.shapes.medium,
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else statusColors.hairline
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (inSelectionMode) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onLongClick() },
                    modifier = Modifier.padding(end = 4.dp)
                )
            }

            FileThumbnailBox(item = item, sizeDp = 42)
            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val badgeLabel = if (item.isObfuscatedExtension) {
                        val decl = item.declaredExtension.uppercase().ifEmpty { "NONE" }
                        "$decl -> ${item.detectedFormat.label}"
                    } else {
                        item.detectedFormat.label
                    }
                    StatusBadgePill(
                        text = badgeLabel,
                        containerColor = if (item.isObfuscatedExtension) statusColors.criticalContainer else MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = if (item.isObfuscatedExtension) statusColors.onCriticalContainer else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (item.isHidden) {
                        StatusBadgePill(
                            text = "Hidden",
                            containerColor = statusColors.warningContainer,
                            contentColor = statusColors.onWarningContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = FormatUtils.formatBytes(item.sizeBytes),
                    style = TabularBodyValue,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (item.durationMs != null && item.durationMs > 0L) {
                    Text(
                        text = FormatUtils.formatDurationMs(item.durationMs),
                        style = TabularCaptionValue,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun FileThumbnailBox(
    item: ScannedFileItem,
    sizeDp: Int
) {
    val context = LocalContext.current
    val isPreviewable = item.category == MediaCategory.IMAGE || item.category == MediaCategory.VIDEO
    val dataModel: Any? = if (isPreviewable) {
        item.uriString?.let(Uri::parse) ?: File(item.path)
    } else {
        null
    }

    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, LocalStatusColors.current.hairline, RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = categoryIcon(item.category),
            contentDescription = stringResource(R.string.cd_file_thumbnail),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
        if (dataModel != null) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(dataModel)
                    .crossfade(true)
                    .build(),
                contentDescription = stringResource(R.string.cd_file_thumbnail),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (item.category == MediaCategory.VIDEO) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.78f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PlayCircleOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

private fun categoryIcon(category: MediaCategory): ImageVector = when (category) {
    MediaCategory.VIDEO -> Icons.Outlined.PlayCircleOutline
    MediaCategory.IMAGE -> Icons.Outlined.Image
    MediaCategory.AUDIO -> Icons.Outlined.AudioFile
    MediaCategory.APK -> Icons.Outlined.Android
    MediaCategory.ARCHIVE -> Icons.Outlined.Archive
    MediaCategory.DOCUMENT -> Icons.Outlined.Description
    MediaCategory.HIDDEN_MARKER -> Icons.Outlined.VisibilityOff
    MediaCategory.OTHER -> Icons.Outlined.InsertDriveFile
}
