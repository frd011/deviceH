package com.example.ui.screens.scanner

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.DetectedFormat
import com.example.domain.model.FormatBreakdown
import com.example.domain.model.MediaCategory
import com.example.domain.model.ScanProgressState
import com.example.domain.model.ScannedFileItem
import com.example.domain.model.StorageAccessMode
import com.example.domain.repository.CacheCleanerRepository
import com.example.domain.usecase.DeleteScannedFilesUseCase
import com.example.domain.usecase.ScanStorageUseCase
import com.example.util.FormatUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ScannerUiState(
    val accessMode: StorageAccessMode = StorageAccessMode.NEEDS_PERMISSION,
    val scanState: ScanProgressState = ScanProgressState.Idle,
    val hiddenOnly: Boolean = false,
    val obfuscatedOnly: Boolean = false,
    val selectedCategory: MediaCategory? = null,
    val selectedFormat: DetectedFormat? = null,
    val filteredFiles: List<ScannedFileItem> = emptyList(),
    val selectedFileIds: Set<String> = emptySet(),
    val selectedTotalBytes: Long = 0L,
    val inspectedFile: ScannedFileItem? = null,
    val isDeleting: Boolean = false,
    val showDeleteSheet: Boolean = false,
    val statusMessage: String? = null
)

class ScannerViewModel(
    private val scanStorageUseCase: ScanStorageUseCase,
    private val deleteScannedFilesUseCase: DeleteScannedFilesUseCase,
    private val cacheCleanerRepository: CacheCleanerRepository
) : ViewModel() {

    private val accessMode = MutableStateFlow(cacheCleanerRepository.getStorageAccessMode())
    private val scanState = MutableStateFlow<ScanProgressState>(ScanProgressState.Idle)
    private val hiddenOnly = MutableStateFlow(false)
    private val obfuscatedOnly = MutableStateFlow(false)
    private val selectedCategory = MutableStateFlow<MediaCategory?>(null)
    private val selectedFormat = MutableStateFlow<DetectedFormat?>(null)
    private val selectedIds = MutableStateFlow<Set<String>>(emptySet())
    private val inspectedFile = MutableStateFlow<ScannedFileItem?>(null)
    private val isDeleting = MutableStateFlow(false)
    private val showDeleteSheet = MutableStateFlow(false)
    private val statusMessage = MutableStateFlow<String?>(null)

    private var scanJob: Job? = null

    private val filterFlow = combine(
        hiddenOnly,
        obfuscatedOnly,
        selectedCategory,
        selectedFormat
    ) { hidden, obfuscated, category, format ->
        FilterParams(hidden, obfuscated, category, format)
    }

    private val modalFlow = combine(
        selectedIds,
        inspectedFile,
        isDeleting,
        showDeleteSheet,
        statusMessage
    ) { ids, inspected, deleting, deleteSheet, msg ->
        ModalParams(ids, inspected, deleting, deleteSheet, msg)
    }

    val uiState: StateFlow<ScannerUiState> = combine(
        accessMode,
        scanState,
        filterFlow,
        modalFlow
    ) { mode, state, filters, modals ->
        val completed = state as? ScanProgressState.Completed
        val allFiles = completed?.files.orEmpty()
        val filtered = allFiles.filter { item ->
            (!filters.hiddenOnly || item.isHidden) &&
                (!filters.obfuscatedOnly || item.isObfuscatedExtension) &&
                (filters.category == null || item.category == filters.category) &&
                (filters.format == null || item.detectedFormat == filters.format)
        }
        val validSelection = modals.selectedIds.intersect(allFiles.map { it.id }.toSet())
        val selectedBytes = allFiles
            .asSequence()
            .filter { it.id in validSelection }
            .sumOf { it.sizeBytes }

        ScannerUiState(
            accessMode = mode,
            scanState = state,
            hiddenOnly = filters.hiddenOnly,
            obfuscatedOnly = filters.obfuscatedOnly,
            selectedCategory = filters.category,
            selectedFormat = filters.format,
            filteredFiles = filtered,
            selectedFileIds = validSelection,
            selectedTotalBytes = selectedBytes,
            inspectedFile = modals.inspectedFile,
            isDeleting = modals.isDeleting,
            showDeleteSheet = modals.showDeleteSheet,
            statusMessage = modals.statusMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ScannerUiState(accessMode = cacheCleanerRepository.getStorageAccessMode())
    )

    init {
        if (accessMode.value != StorageAccessMode.NEEDS_PERMISSION) {
            startScan()
        }
    }

    fun refreshAccessMode(autoScanIfNewlyGranted: Boolean = true) {
        val prev = accessMode.value
        val current = cacheCleanerRepository.getStorageAccessMode()
        accessMode.value = current
        if (autoScanIfNewlyGranted &&
            prev == StorageAccessMode.NEEDS_PERMISSION &&
            current != StorageAccessMode.NEEDS_PERMISSION &&
            scanState.value is ScanProgressState.Idle
        ) {
            startScan()
        }
    }

    fun onSafTreeSelected(uri: Uri) {
        viewModelScope.launch {
            cacheCleanerRepository.persistSafTreeUri(uri)
            accessMode.value = cacheCleanerRepository.getStorageAccessMode()
            startScan()
        }
    }

    fun startScan() {
        scanJob?.cancel()
        selectedIds.value = emptySet()
        statusMessage.value = null
        val safUris = cacheCleanerRepository.getPersistedSafUris()
        scanJob = viewModelScope.launch {
            try {
                scanStorageUseCase(safUris).collect { state ->
                    scanState.value = state
                }
            } catch (e: Exception) {
                scanState.value = ScanProgressState.Error(
                    e.message ?: "Unable to complete storage scan."
                )
            }
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        scanJob = null
        if (scanState.value is ScanProgressState.Scanning) {
            scanState.value = ScanProgressState.Idle
        }
    }

    fun toggleHiddenOnly() {
        hiddenOnly.update { !it }
    }

    fun toggleObfuscatedOnly() {
        obfuscatedOnly.update { !it }
    }

    fun selectCategory(category: MediaCategory?) {
        selectedCategory.update { if (it == category) null else category }
        selectedFormat.value = null
    }

    fun selectFormat(format: DetectedFormat?) {
        selectedFormat.update { if (it == format) null else format }
    }

    fun toggleFileSelection(fileId: String) {
        selectedIds.update { current ->
            if (fileId in current) current - fileId else current + fileId
        }
    }

    fun selectAllFiltered() {
        val ids = uiState.value.filteredFiles.map { it.id }.toSet()
        selectedIds.value = ids
    }

    fun clearSelection() {
        selectedIds.value = emptySet()
    }

    fun inspectFile(item: ScannedFileItem?) {
        inspectedFile.value = item
    }

    fun openDeleteConfirmation() {
        if (uiState.value.selectedFileIds.isNotEmpty()) {
            showDeleteSheet.value = true
        }
    }

    fun dismissDeleteConfirmation() {
        showDeleteSheet.value = false
    }

    fun deleteSelectedFiles() {
        val currentCompleted = scanState.value as? ScanProgressState.Completed ?: return
        val idsToDelete = uiState.value.selectedFileIds
        if (idsToDelete.isEmpty()) return

        val targets = currentCompleted.files.filter { it.id in idsToDelete }
        viewModelScope.launch {
            isDeleting.value = true
            val result = deleteScannedFilesUseCase(targets)
            val remaining = currentCompleted.files.filterNot { it.id in result.deletedIds }
            val breakdowns = remaining
                .groupBy { it.detectedFormat }
                .map { (format, group) ->
                    FormatBreakdown(
                        format = format,
                        count = group.size,
                        totalBytes = group.sumOf { it.sizeBytes }
                    )
                }
                .sortedByDescending { it.totalBytes }

            scanState.value = currentCompleted.copy(
                files = remaining,
                totalBytes = remaining.sumOf { it.sizeBytes },
                hiddenCount = remaining.count { it.isHidden },
                obfuscatedCount = remaining.count { it.isObfuscatedExtension },
                formatBreakdowns = breakdowns
            )
            selectedIds.value = emptySet()
            inspectedFile.value = null
            showDeleteSheet.value = false
            isDeleting.value = false
            statusMessage.value = "Freed ${FormatUtils.formatBytes(result.freedBytes)} (${result.deletedCount} files removed)"
        }
    }

    fun deleteSingleInspectedFile() {
        val item = inspectedFile.value ?: return
        selectedIds.value = setOf(item.id)
        inspectedFile.value = null
        showDeleteSheet.value = true
    }

    fun clearStatusMessage() {
        statusMessage.value = null
    }

    private data class FilterParams(
        val hiddenOnly: Boolean,
        val obfuscatedOnly: Boolean,
        val category: MediaCategory?,
        val format: DetectedFormat?
    )

    private data class ModalParams(
        val selectedIds: Set<String>,
        val inspectedFile: ScannedFileItem?,
        val isDeleting: Boolean,
        val showDeleteSheet: Boolean,
        val statusMessage: String?
    )

    companion object {
        fun factory(
            scanStorageUseCase: ScanStorageUseCase,
            deleteScannedFilesUseCase: DeleteScannedFilesUseCase,
            cacheCleanerRepository: CacheCleanerRepository
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return ScannerViewModel(
                    scanStorageUseCase = scanStorageUseCase,
                    deleteScannedFilesUseCase = deleteScannedFilesUseCase,
                    cacheCleanerRepository = cacheCleanerRepository
                ) as T
            }
        }
    }
}
