package com.example.ui.screens.battery

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Autorenew
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.BatteryStd
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.ElectricMeter
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.domain.model.BatteryCondition
import com.example.domain.model.BatteryStatusSnapshot
import com.example.domain.model.ChargingSessionRecord
import com.example.ui.components.CompactIconBadge
import com.example.ui.components.EmptyStateBlock
import com.example.ui.components.HairlineDivider
import com.example.ui.components.KeyValueDetailRow
import com.example.ui.components.LiveCurrentSparkline
import com.example.ui.components.PrecisionArcGauge
import com.example.ui.components.SectionHeaderRow
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.TactileSurfaceCard
import com.example.ui.theme.LocalStatusColors
import com.example.ui.theme.TabularBodyValue
import com.example.ui.theme.TabularCaptionValue
import com.example.ui.theme.TabularCardMetric
import com.example.util.FormatUtils
import java.util.Locale

@Composable
fun BatteryScreen(
    viewModel: BatteryViewModel,
    modifier: Modifier = Modifier
) {
    val snapshot by viewModel.snapshot.collectAsStateWithLifecycle()
    val currentSamples by viewModel.currentSamplesMa.collectAsStateWithLifecycle()
    val showDesignDialog by viewModel.showDesignCapacityDialog.collectAsStateWithLifecycle()
    val statusColors = LocalStatusColors.current

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = stringResource(R.string.battery_title),
                style = MaterialTheme.typography.headlineSmall
            )
            snapshot?.let { data ->
                StatusBadgePill(
                    text = "${data.levelPercent}% · ${if (data.isCharging) data.chargeSource else "On Battery"}",
                    containerColor = if (data.isCharging) statusColors.healthyContainer else MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = if (data.isCharging) statusColors.onHealthyContainer else MaterialTheme.colorScheme.onSurface,
                    icon = if (data.isCharging) Icons.Outlined.BatteryChargingFull else Icons.Outlined.BatteryStd
                )
            }
        }

        val data = snapshot
        if (data == null) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            )
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Precision Arc Gauge Health Hero Card
            item(key = "battery_hero") {
                BatteryHealthHeroCard(
                    snapshot = data,
                    onEditDesignCapacity = { viewModel.setDesignCapacityDialogVisible(true) }
                )
            }

            // Live Current Waveform Card
            item(key = "current_waveform_card") {
                val currentSign = if (data.currentNowMa > 0) "+" else ""
                val currentColor = when {
                    data.currentNowMa > 0 -> statusColors.healthy
                    data.currentNowMa < -800 -> statusColors.warning
                    else -> MaterialTheme.colorScheme.primary
                }
                TactileSurfaceCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CompactIconBadge(
                                icon = Icons.Outlined.Bolt,
                                containerColor = if (data.isCharging) statusColors.healthyContainer else MaterialTheme.colorScheme.surfaceVariant,
                                iconTint = currentColor
                            )
                            Column {
                                Text(
                                    text = "LIVE CURRENT",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "$currentSign${FormatUtils.formatCount(data.currentNowMa)} mA",
                                    style = TabularCardMetric,
                                    color = currentColor
                                )
                            }
                        }
                        StatusBadgePill(
                            text = String.format(Locale.US, "%.1f W", data.powerWatts),
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    LiveCurrentSparkline(
                        samplesMa = currentSamples,
                        accentColor = currentColor
                    )
                }
            }

            // Clean 2x2 Telemetry Grid
            item(key = "telemetry_grid") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TelemetryTile(
                            icon = Icons.Outlined.ElectricMeter,
                            iconBg = statusColors.infoContainer,
                            iconTint = statusColors.onInfoContainer,
                            label = "VOLTAGE",
                            value = FormatUtils.formatVoltageV(data.voltageMv),
                            modifier = Modifier.weight(1f)
                        )
                        val tempColor = when {
                            data.temperatureC >= 42f -> statusColors.critical
                            data.temperatureC >= 37f -> statusColors.warning
                            else -> statusColors.healthy
                        }
                        TelemetryTile(
                            icon = Icons.Outlined.Thermostat,
                            iconBg = if (data.temperatureC >= 37f) statusColors.warningContainer else statusColors.healthyContainer,
                            iconTint = tempColor,
                            label = "TEMPERATURE",
                            value = FormatUtils.formatTempC(data.temperatureC),
                            valueColor = tempColor,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TelemetryTile(
                            icon = Icons.Outlined.Autorenew,
                            iconBg = MaterialTheme.colorScheme.surfaceVariant,
                            iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                            label = "CYCLES",
                            value = data.cycleCount?.let { "$it" } ?: "—",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryTile(
                            icon = Icons.Outlined.Memory,
                            iconBg = MaterialTheme.colorScheme.surfaceVariant,
                            iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                            label = "CHEMISTRY",
                            value = data.technology,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Hardware Cell Diagnostics
            item(key = "diagnostics_card") {
                TactileSurfaceCard {
                    Text(
                        text = "Cell Diagnostics",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    HairlineDivider()
                    KeyValueDetailRow(
                        label = "Source",
                        value = data.estimationMethod.label
                    )
                    KeyValueDetailRow(
                        label = "Charge Counter",
                        value = data.chargeCounterMah?.let { "${FormatUtils.formatCount(it)} mAh" } ?: "Unavailable",
                        monospaceValue = true
                    )
                    KeyValueDetailRow(
                        label = "OS Health",
                        value = data.osHealthLabel
                    )
                }
            }

            // Charging Session History
            item(key = "sessions_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SectionHeaderRow(
                        title = "CHARGING SESSIONS",
                        trailing = "${data.recentSessions.size}",
                        modifier = Modifier.weight(1f)
                    )
                    if (data.recentSessions.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.clearSessionHistory() },
                            modifier = Modifier.testTag("battery_clear_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = "Clear charging session logs",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            if (data.recentSessions.isEmpty()) {
                item(key = "empty_sessions") {
                    TactileSurfaceCard(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                        EmptyStateBlock(
                            icon = Icons.Outlined.Bolt,
                            title = "No Sessions Logged",
                            description = "Sessions record automatically while charging"
                        )
                    }
                }
            } else {
                items(
                    items = data.recentSessions,
                    key = { it.id }
                ) { session ->
                    ChargingSessionRow(session = session)
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showDesignDialog && snapshot != null) {
        DesignCapacityEditDialog(
            currentCapacityMah = snapshot!!.designCapacityMah,
            isCustom = snapshot!!.isCustomDesignCapacity,
            onDismiss = { viewModel.setDesignCapacityDialogVisible(false) },
            onSave = { viewModel.updateCustomDesignCapacity(it) }
        )
    }
}

@Composable
private fun BatteryHealthHeroCard(
    snapshot: BatteryStatusSnapshot,
    onEditDesignCapacity: () -> Unit
) {
    val statusColors = LocalStatusColors.current
    val (accentColor, badgeBg, badgeFg, statusText) = when (snapshot.condition) {
        BatteryCondition.HEALTHY -> Quad(
            statusColors.healthy,
            statusColors.healthyContainer,
            statusColors.onHealthyContainer,
            "Healthy"
        )
        BatteryCondition.MODERATE -> Quad(
            statusColors.warning,
            statusColors.warningContainer,
            statusColors.onWarningContainer,
            "Moderate"
        )
        BatteryCondition.DEGRADED -> Quad(
            statusColors.critical,
            statusColors.criticalContainer,
            statusColors.onCriticalContainer,
            "Degraded"
        )
    }

    TactileSurfaceCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            PrecisionArcGauge(
                progress = snapshot.estimatedHealthPercent / 100f,
                centerTitle = "${snapshot.estimatedHealthPercent}%",
                centerSubtitle = "HEALTH",
                accentColor = accentColor,
                size = 128.dp,
                strokeWidth = 11.dp
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadgePill(
                        text = statusText,
                        containerColor = badgeBg,
                        contentColor = badgeFg
                    )
                    IconButton(
                        onClick = onEditDesignCapacity,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("battery_edit_design_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = "Calibrate design capacity",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Est. Full",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${FormatUtils.formatCount(snapshot.estimatedFullCapacityMah)} mAh",
                        style = TabularBodyValue
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Design",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${FormatUtils.formatCount(snapshot.designCapacityMah)} mAh",
                        style = TabularBodyValue,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryTile(
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    TactileSurfaceCard(modifier = modifier) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CompactIconBadge(
                icon = icon,
                containerColor = iconBg,
                iconTint = iconTint,
                boxSize = 30.dp
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = value,
            style = TabularCardMetric,
            color = valueColor
        )
    }
}

@Composable
private fun ChargingSessionRow(session: ChargingSessionRecord) {
    val statusColors = LocalStatusColors.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, statusColors.hairline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${session.startLevel}% -> ${session.endLevel}% (+${session.deltaMah} mAh)",
                    style = TabularBodyValue,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = FormatUtils.formatDateTime(session.timestampMs),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${FormatUtils.formatCount(session.estimatedFullMah)} mAh",
                    style = TabularBodyValue,
                    color = statusColors.healthy
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Thermostat,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = FormatUtils.formatTempC(session.avgTempC),
                        style = TabularCaptionValue,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun DesignCapacityEditDialog(
    currentCapacityMah: Int,
    isCustom: Boolean,
    onDismiss: () -> Unit,
    onSave: (Int?) -> Unit
) {
    var inputText by remember(currentCapacityMah) { mutableStateOf(currentCapacityMah.toString()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Design Capacity") },
        text = {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Rated Capacity (mAh)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        },
        dismissButton = {
            Row {
                if (isCustom) {
                    TextButton(onClick = { onSave(null) }) {
                        Text("Reset")
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val parsed = inputText.toIntOrNull()
                    if (parsed != null && parsed >= 500) {
                        onSave(parsed)
                    }
                }
            ) {
                Text("Save")
            }
        }
    )
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
