package com.example.ui.screens.apps

import android.graphics.drawable.Drawable
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Sort
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.domain.model.AppCategoryFilter
import com.example.domain.model.AppSortOption
import com.example.domain.model.InstalledAppInfo
import com.example.ui.components.CompactIconBadge
import com.example.ui.components.EmptyStateBlock
import com.example.ui.components.HairlineDivider
import com.example.ui.components.KeyValueDetailRow
import com.example.ui.components.SegmentedStorageBar
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.StorageSegment
import com.example.ui.components.TactileSurfaceCard
import com.example.ui.theme.LocalStatusColors
import com.example.ui.theme.TabularBodyValue
import com.example.ui.theme.TabularCaptionValue
import com.example.ui.theme.TabularCardMetric
import com.example.util.FormatUtils
import com.example.util.StoragePermissionUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(
    viewModel: AppsViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val statusColors = LocalStatusColors.current
    var sortMenuExpanded by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshApps()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = stringResource(R.string.apps_title),
                    style = MaterialTheme.typography.headlineSmall
                )
                StatusBadgePill(
                    text = "${uiState.filteredApps.size}",
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row {
                Box {
                    IconButton(
                        onClick = { sortMenuExpanded = true },
                        modifier = Modifier.testTag("apps_sort_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.Sort,
                            contentDescription = "Sort apps"
                        )
                    }
                    DropdownMenu(
                        expanded = sortMenuExpanded,
                        onDismissRequest = { sortMenuExpanded = false }
                    ) {
                        AppSortOption.entries.forEach { option ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (uiState.sortOption == option) {
                                            "✓ ${option.label}"
                                        } else {
                                            option.label
                                        }
                                    )
                                },
                                onClick = {
                                    viewModel.setSortOption(option)
                                    sortMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                IconButton(
                    onClick = { viewModel.refreshApps() },
                    modifier = Modifier.testTag("apps_refresh_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Refresh,
                        contentDescription = "Refresh installed apps"
                    )
                }
            }
        }

        if (uiState.isLoading) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            )
        }

        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Search apps...") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = null
                )
            },
            singleLine = true,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .testTag("apps_search_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppCategoryFilter.entries.forEach { category ->
                FilterChip(
                    selected = uiState.categoryFilter == category,
                    onClick = { viewModel.setCategoryFilter(category) },
                    label = { Text(category.label) }
                )
            }
            StatusBadgePill(
                text = uiState.sortOption.label,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (!uiState.hasUsageAccess) {
                item(key = "usage_access_card") {
                    TactileSurfaceCard(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                CompactIconBadge(
                                    icon = Icons.Outlined.QueryStats,
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    iconTint = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Grant Usage Access for cache & data stats",
                                    style = MaterialTheme.typography.titleSmall
                                )
                            }
                            TextButton(
                                onClick = {
                                    context.startActivity(
                                        StoragePermissionUtils.buildUsageAccessIntent(context)
                                    )
                                },
                                modifier = Modifier.testTag("apps_grant_usage_button")
                            ) {
                                Text("Enable")
                            }
                        }
                    }
                }
            }

            if (uiState.totalFootprintBytes > 0L) {
                item(key = "apps_footprint_visual") {
                    val appBytesSum = uiState.filteredApps.sumOf { it.appBytes }
                    val dataBytesSum = uiState.filteredApps.sumOf { it.dataBytes }
                    val cacheBytesSum = uiState.filteredApps.sumOf { it.cacheBytes }
                    TactileSurfaceCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "TOTAL FOOTPRINT",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = FormatUtils.formatBytes(uiState.totalFootprintBytes),
                                    style = TabularCardMetric
                                )
                            }
                            if (cacheBytesSum > 0L) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "TOTAL CACHE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = FormatUtils.formatBytes(cacheBytesSum),
                                        style = TabularCardMetric,
                                        color = statusColors.warning
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        SegmentedStorageBar(
                            segments = listOf(
                                StorageSegment(
                                    label = "Apps",
                                    bytes = appBytesSum,
                                    color = MaterialTheme.colorScheme.primary
                                ),
                                StorageSegment(
                                    label = "Data",
                                    bytes = dataBytesSum,
                                    color = statusColors.info
                                ),
                                StorageSegment(
                                    label = "Cache",
                                    bytes = cacheBytesSum,
                                    color = statusColors.warning
                                )
                            ),
                            totalReferenceBytes = uiState.totalFootprintBytes
                        )
                    }
                }
            }

            if (!uiState.isLoading && uiState.filteredApps.isEmpty()) {
                item(key = "empty_apps") {
                    EmptyStateBlock(
                        icon = Icons.Outlined.Apps,
                        title = "No Apps Found",
                        description = "Try clearing the search query"
                    )
                }
            } else {
                items(
                    items = uiState.filteredApps,
                    key = { it.packageName }
                ) { app ->
                    InstalledAppRow(
                        app = app,
                        hasUsageStats = uiState.hasUsageAccess,
                        onClick = { viewModel.selectApp(app) }
                    )
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    uiState.selectedApp?.let { app ->
        ModalBottomSheet(
            onDismissRequest = { viewModel.selectApp(null) },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AppIconBox(packageName = app.packageName, sizeDp = 46)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = app.appName,
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${app.packageName} · v${app.versionName}",
                            style = TabularCaptionValue,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HairlineDivider()
                KeyValueDetailRow(
                    label = "App Binary",
                    value = FormatUtils.formatBytes(app.appBytes),
                    monospaceValue = true
                )
                KeyValueDetailRow(
                    label = "User Data",
                    value = FormatUtils.formatBytes(app.dataBytes),
                    monospaceValue = true
                )
                KeyValueDetailRow(
                    label = "App Cache",
                    value = FormatUtils.formatBytes(app.cacheBytes),
                    valueColor = if (app.cacheBytes > 50 * 1024 * 1024L) statusColors.warning else MaterialTheme.colorScheme.onSurface,
                    monospaceValue = true
                )
                KeyValueDetailRow(
                    label = "Total",
                    value = FormatUtils.formatBytes(app.totalBytes),
                    monospaceValue = true
                )
                KeyValueDetailRow(
                    label = "Last Used",
                    value = FormatUtils.formatRelativeTime(app.lastUsedMs)
                )

                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            context.startActivity(
                                StoragePermissionUtils.buildAppDetailsIntent(app.packageName)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("app_sheet_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Settings")
                    }

                    if (app.canUninstall) {
                        Button(
                            onClick = {
                                viewModel.selectApp(null)
                                context.startActivity(
                                    StoragePermissionUtils.buildUninstallIntent(app.packageName)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = statusColors.critical,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("app_sheet_uninstall_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Uninstall")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InstalledAppRow(
    app: InstalledAppInfo,
    hasUsageStats: Boolean,
    onClick: () -> Unit
) {
    val statusColors = LocalStatusColors.current
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .testTag("app_row_${app.packageName}"),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, statusColors.hairline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIconBox(packageName = app.packageName, sizeDp = 40)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = app.appName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (hasUsageStats || app.isSystemApp) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (app.isSystemApp) {
                            StatusBadgePill(
                                text = "System",
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (hasUsageStats && app.lastUsedMs > 0L) {
                            StatusBadgePill(
                                text = FormatUtils.formatRelativeTime(app.lastUsedMs),
                                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = FormatUtils.formatBytes(app.totalBytes),
                    style = TabularBodyValue,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (hasUsageStats && app.cacheBytes > 0L) {
                    Text(
                        text = FormatUtils.formatBytes(app.cacheBytes),
                        style = TabularCaptionValue,
                        color = if (app.cacheBytes > 50 * 1024 * 1024L) statusColors.warning else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun AppIconBox(
    packageName: String,
    sizeDp: Int
) {
    val context = LocalContext.current
    val drawable by produceState<Drawable?>(initialValue = null, packageName) {
        value = withContext(Dispatchers.IO) {
            try {
                context.packageManager.getApplicationIcon(packageName)
            } catch (_: Exception) {
                null
            }
        }
    }

    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (drawable != null) {
            AsyncImage(
                model = drawable,
                contentDescription = stringResource(R.string.cd_app_icon),
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                imageVector = Icons.Outlined.Apps,
                contentDescription = stringResource(R.string.cd_app_icon),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
