package com.example.di

import android.content.Context
import com.example.data.apps.AppManagerRepositoryImpl
import com.example.data.battery.BatteryRepositoryImpl
import com.example.data.cleaner.CacheCleanerRepositoryImpl
import com.example.data.scanner.FileScannerRepositoryImpl
import com.example.data.scanner.MagicNumberInspector
import com.example.domain.repository.AppManagerRepository
import com.example.domain.repository.BatteryRepository
import com.example.domain.repository.CacheCleanerRepository
import com.example.domain.repository.FileScannerRepository
import com.example.domain.usecase.DeleteScannedFilesUseCase
import com.example.domain.usecase.LoadInstalledAppsUseCase
import com.example.domain.usecase.ObserveBatteryHealthUseCase
import com.example.domain.usecase.ScanStorageUseCase

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    private val magicNumberInspector by lazy { MagicNumberInspector(appContext) }

    val fileScannerRepository: FileScannerRepository by lazy {
        FileScannerRepositoryImpl(appContext, magicNumberInspector)
    }

    val appManagerRepository: AppManagerRepository by lazy {
        AppManagerRepositoryImpl(appContext)
    }

    val cacheCleanerRepository: CacheCleanerRepository by lazy {
        CacheCleanerRepositoryImpl(appContext, appManagerRepository)
    }

    val batteryRepository: BatteryRepository by lazy {
        BatteryRepositoryImpl(appContext)
    }

    val scanStorageUseCase by lazy { ScanStorageUseCase(fileScannerRepository) }
    val deleteScannedFilesUseCase by lazy { DeleteScannedFilesUseCase(fileScannerRepository) }
    val observeBatteryHealthUseCase by lazy { ObserveBatteryHealthUseCase(batteryRepository) }
    val loadInstalledAppsUseCase by lazy { LoadInstalledAppsUseCase(appManagerRepository) }
}
