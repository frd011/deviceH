package com.example.data.battery

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.BatteryCondition
import com.example.domain.model.BatteryStatusSnapshot
import com.example.domain.model.ChargingSessionRecord
import com.example.domain.model.HealthEstimationMethod
import com.example.domain.repository.BatteryRepository
import java.io.File
import java.util.UUID
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private val Context.batteryDataStore: DataStore<Preferences> by preferencesDataStore(name = "battery_health_prefs")

class BatteryRepositoryImpl(
    private val context: Context
) : BatteryRepository {

    private val customDesignCapKey = intPreferencesKey("custom_design_capacity_mah")
    private val sessionsDataKey = stringPreferencesKey("charging_sessions_serialized")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Active charging session tracker for fallback health estimation
    private var activeSessionStartLevel: Int? = null
    private var activeSessionStartChargeUah: Long? = null
    private var activeSessionStartTimeMs: Long = 0L
    private var tempSamples = ArrayList<Float>()

    override fun observeBatteryHealth(): Flow<BatteryStatusSnapshot> = callbackFlow {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        var lastIntent: Intent? = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        suspend fun emitSnapshot(intent: Intent?) {
            val snapshot = buildSnapshot(intent, batteryManager)
            trySend(snapshot)
        }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                    lastIntent = intent
                    scope.launch {
                        trackChargingSession(intent, batteryManager)
                        emitSnapshot(intent)
                    }
                }
            }
        }

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        ContextCompat.registerReceiver(
            context,
            receiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        // Emit immediate initial reading
        emitSnapshot(lastIntent)

        // Poll live BatteryManager telemetry (current, charge counter) every 2 seconds
        val tickerJob = launch {
            while (isActive) {
                delay(2_000L)
                emitSnapshot(lastIntent)
            }
        }

        awaitClose {
            tickerJob.cancel()
            try {
                context.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun setCustomDesignCapacityMah(capacityMah: Int?) {
        context.batteryDataStore.edit { prefs ->
            if (capacityMah == null || capacityMah <= 0) {
                prefs.remove(customDesignCapKey)
            } else {
                prefs[customDesignCapKey] = capacityMah.coerceIn(500, 25000)
            }
        }
    }

    override suspend fun clearSessionHistory() {
        context.batteryDataStore.edit { prefs ->
            prefs.remove(sessionsDataKey)
        }
    }

    private suspend fun trackChargingSession(intent: Intent, batteryManager: BatteryManager) {
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val level = computeLevelPercent(intent, batteryManager)
        val chargeCounterUah = readChargeCounterUah(batteryManager)
        val tempC = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 250) / 10f

        if (isCharging && chargeCounterUah != null && chargeCounterUah > 0L) {
            if (activeSessionStartLevel == null) {
                activeSessionStartLevel = level
                activeSessionStartChargeUah = chargeCounterUah
                activeSessionStartTimeMs = System.currentTimeMillis()
                tempSamples.clear()
            }
            tempSamples.add(tempC)

            val startLvl = activeSessionStartLevel ?: level
            val startUah = activeSessionStartChargeUah ?: chargeCounterUah
            val deltaLevel = level - startLvl
            val deltaUah = chargeCounterUah - startUah

            if (deltaLevel >= 4 && deltaUah > 20_000L) {
                val deltaMah = (deltaUah / 1000.0).roundToInt()
                val estimatedFull = ((deltaMah.toDouble() / deltaLevel.toDouble()) * 100.0).roundToInt()
                if (estimatedFull in 800..15000) {
                    val avgTemp = if (tempSamples.isNotEmpty()) {
                        tempSamples.average().toFloat()
                    } else {
                        tempC
                    }
                    saveSessionRecord(
                        ChargingSessionRecord(
                            id = UUID.randomUUID().toString(),
                            timestampMs = System.currentTimeMillis(),
                            startLevel = startLvl,
                            endLevel = level,
                            deltaMah = deltaMah,
                            estimatedFullMah = estimatedFull,
                            avgTempC = avgTemp
                        )
                    )
                    // Reset baseline for continuous incremental tracking
                    activeSessionStartLevel = level
                    activeSessionStartChargeUah = chargeCounterUah
                    activeSessionStartTimeMs = System.currentTimeMillis()
                    tempSamples.clear()
                }
            }
        } else {
            activeSessionStartLevel = null
            activeSessionStartChargeUah = null
            tempSamples.clear()
        }
    }

    private suspend fun buildSnapshot(
        intent: Intent?,
        batteryManager: BatteryManager
    ): BatteryStatusSnapshot {
        val prefs = context.batteryDataStore.data.first()
        val customDesign = prefs[customDesignCapKey]
        val recentSessions = decodeSessions(prefs[sessionsDataKey])

        val levelPercent = computeLevelPercent(intent, batteryManager)
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val chargeSource = when {
            plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "AC Fast"
            plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "USB"
            plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "Wireless"
            else -> "Discharging"
        }

        val chargingStatusLabel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Charging ($chargeSource)"
                BatteryManager.BATTERY_STATUS_FULL -> "Full"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "On Battery"
                else -> mapStatusFallback(status, chargeSource)
            }
        } else {
            mapStatusFallback(status, chargeSource)
        }

        val voltageMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)?.coerceAtLeast(0) ?: 0
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val temperatureC = tempTenths / 10f
        val technology = intent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.ifBlank { "Li-ion" } ?: "Li-ion"

        val osHealth = intent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
            ?: BatteryManager.BATTERY_HEALTH_UNKNOWN
        val osHealthLabel = when (osHealth) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Unknown"
        }

        val currentNowMa = readNormalizedCurrentMa(batteryManager, isCharging)
        val powerWatts = if (voltageMv > 0) {
            abs((voltageMv / 1000f) * (currentNowMa / 1000f))
        } else {
            0f
        }

        val cycleCount = readCycleCount(intent)
        val chargeCounterUah = readChargeCounterUah(batteryManager)
        val chargeCounterMah = chargeCounterUah?.let { (it / 1000L).toInt() }

        val sysfsDesignMah = readSysfsCapacityMah("/sys/class/power_supply/battery/charge_full_design")
        val powerProfileDesignMah = readPowerProfileCapacityMah()
        val designCapacityMah = customDesign ?: sysfsDesignMah ?: powerProfileDesignMah ?: 4500

        val sysfsFullMah = readSysfsCapacityMah("/sys/class/power_supply/battery/charge_full")

        val (estimatedFullMah, method) = when {
            sysfsFullMah != null && sysfsFullMah in 500..20000 -> {
                sysfsFullMah to HealthEstimationMethod.KERNEL_CHARGE_FULL
            }
            chargeCounterMah != null && chargeCounterMah > 200 && levelPercent >= 15 -> {
                val extrapolated = ((chargeCounterMah.toDouble() / levelPercent.toDouble()) * 100.0).roundToInt()
                extrapolated.coerceIn(500, 20000) to HealthEstimationMethod.CHARGE_COUNTER_SESSION
            }
            recentSessions.isNotEmpty() -> {
                val avg = recentSessions.map { it.estimatedFullMah }.average().roundToInt()
                avg.coerceIn(500, 20000) to HealthEstimationMethod.SESSION_HISTORY_FALLBACK
            }
            else -> {
                designCapacityMah to HealthEstimationMethod.SESSION_HISTORY_FALLBACK
            }
        }

        val healthPct = ((estimatedFullMah.toFloat() / designCapacityMah.toFloat()) * 100f)
            .roundToInt()
            .coerceIn(1, 100)

        val condition = when {
            healthPct >= 85 -> BatteryCondition.HEALTHY
            healthPct >= 75 -> BatteryCondition.MODERATE
            else -> BatteryCondition.DEGRADED
        }

        return BatteryStatusSnapshot(
            levelPercent = levelPercent,
            isCharging = isCharging,
            chargeSource = chargeSource,
            chargingStatusLabel = chargingStatusLabel,
            voltageMv = voltageMv,
            temperatureC = temperatureC,
            currentNowMa = currentNowMa,
            powerWatts = powerWatts,
            technology = technology,
            osHealthLabel = osHealthLabel,
            cycleCount = cycleCount,
            chargeCounterMah = chargeCounterMah,
            designCapacityMah = designCapacityMah,
            estimatedFullCapacityMah = estimatedFullMah,
            estimatedHealthPercent = healthPct,
            condition = condition,
            estimationMethod = method,
            isCustomDesignCapacity = customDesign != null,
            recentSessions = recentSessions,
            timestampMs = System.currentTimeMillis()
        )
    }

    private fun mapStatusFallback(status: Int, chargeSource: String): String {
        return when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging ($chargeSource)"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Plugged (Not Charging)"
            else -> "On Battery"
        }
    }

    private fun computeLevelPercent(intent: Intent?, batteryManager: BatteryManager): Int {
        val rawLevel = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (rawLevel >= 0 && scale > 0) {
            return ((rawLevel * 100f) / scale.toFloat()).roundToInt().coerceIn(0, 100)
        }
        val prop = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return prop.coerceIn(0, 100)
    }

    private fun readNormalizedCurrentMa(batteryManager: BatteryManager, isCharging: Boolean): Int {
        val raw = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (raw == Int.MIN_VALUE || raw == 0) return 0
        // Android API defines CURRENT_NOW in microamperes, though some OEM HALs return milliamperes
        val ma = if (abs(raw) > 20_000) raw / 1000 else raw
        // Ensure sign clarity: positive when charging, negative when discharging
        return if (isCharging) abs(ma) else -abs(ma)
    }

    private fun readChargeCounterUah(batteryManager: BatteryManager): Long? {
        val raw = batteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        if (raw == Long.MIN_VALUE || raw <= 0L) return null
        return raw
    }

    private fun readCycleCount(intent: Intent?): Int? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val extra = intent?.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) ?: -1
            if (extra >= 0) return extra
        }
        return try {
            val text = File("/sys/class/power_supply/battery/cycle_count").takeIf { it.canRead() }
                ?.readText()?.trim()
            text?.toIntOrNull()?.takeIf { it >= 0 }
        } catch (_: Exception) {
            null
        }
    }

    private fun readSysfsCapacityMah(path: String): Int? {
        return try {
            val file = File(path)
            if (!file.exists() || !file.canRead()) return null
            val raw = file.readText().trim().toLongOrNull() ?: return null
            when {
                raw > 100_000L -> (raw / 1000L).toInt() // uAh -> mAh
                raw in 500L..25_000L -> raw.toInt() // already mAh
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    @SuppressLint("PrivateApi")
    private fun readPowerProfileCapacityMah(): Int? {
        return try {
            val cls = Class.forName("com.android.internal.os.PowerProfile")
            val ctor = cls.getConstructor(Context::class.java)
            val instance = ctor.newInstance(context)
            val method = cls.getMethod("getBatteryCapacity")
            val capacity = (method.invoke(instance) as? Double)?.roundToInt()
            capacity?.takeIf { it in 500..25_000 }
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun saveSessionRecord(record: ChargingSessionRecord) {
        context.batteryDataStore.edit { prefs ->
            val existing = decodeSessions(prefs[sessionsDataKey]).toMutableList()
            existing.add(0, record)
            val trimmed = existing.take(20)
            prefs[sessionsDataKey] = encodeSessions(trimmed)
        }
    }

    private fun encodeSessions(list: List<ChargingSessionRecord>): String {
        return list.joinToString(";") { r ->
            "${r.id}|${r.timestampMs}|${r.startLevel}|${r.endLevel}|${r.deltaMah}|${r.estimatedFullMah}|${r.avgTempC}"
        }
    }

    private fun decodeSessions(raw: String?): List<ChargingSessionRecord> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(";").mapNotNull { row ->
            val parts = row.split("|")
            if (parts.size != 7) return@mapNotNull null
            try {
                ChargingSessionRecord(
                    id = parts[0],
                    timestampMs = parts[1].toLong(),
                    startLevel = parts[2].toInt(),
                    endLevel = parts[3].toInt(),
                    deltaMah = parts[4].toInt(),
                    estimatedFullMah = parts[5].toInt(),
                    avgTempC = parts[6].toFloat()
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}
