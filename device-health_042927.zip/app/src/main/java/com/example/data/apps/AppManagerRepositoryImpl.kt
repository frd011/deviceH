package com.example.data.apps

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import com.example.domain.model.InstalledAppInfo
import com.example.domain.repository.AppManagerRepository
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppManagerRepositoryImpl(
    private val context: Context
) : AppManagerRepository {

    override fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    override suspend fun loadInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val hasUsageStats = hasUsageStatsPermission()

        val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        }

        val lastUsedMap = if (hasUsageStats) queryLastUsedMap() else emptyMap()
        val storageStatsManager = if (hasUsageStats && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
        } else {
            null
        }
        val userHandle = Process.myUserHandle()

        apps.mapNotNull { appInfo ->
            val pkg = appInfo.packageName ?: return@mapNotNull null
            val label = try {
                pm.getApplicationLabel(appInfo).toString()
            } catch (_: Exception) {
                pkg
            }

            val versionName = try {
                val pInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkg, 0)
                }
                pInfo.versionName ?: "1.0"
            } catch (_: Exception) {
                "1.0"
            }

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isUpdatedSystem = (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            val canUninstall = pkg != context.packageName && (!isSystem || isUpdatedSystem)

            var appBytes = 0L
            var dataBytes = 0L
            var cacheBytes = 0L

            if (storageStatsManager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    val stats = storageStatsManager.queryStatsForPackage(
                        StorageManager.UUID_DEFAULT,
                        pkg,
                        userHandle
                    )
                    appBytes = stats.appBytes
                    dataBytes = stats.dataBytes
                    cacheBytes = stats.cacheBytes
                } catch (_: Exception) {
                    appBytes = estimateApkSize(appInfo)
                }
            } else {
                appBytes = estimateApkSize(appInfo)
            }

            InstalledAppInfo(
                packageName = pkg,
                appName = label,
                versionName = versionName,
                isSystemApp = isSystem,
                appBytes = appBytes,
                dataBytes = dataBytes,
                cacheBytes = cacheBytes,
                totalBytes = appBytes + dataBytes + cacheBytes,
                lastUsedMs = lastUsedMap[pkg] ?: 0L,
                canUninstall = canUninstall
            )
        }
    }

    private fun estimateApkSize(appInfo: ApplicationInfo): Long {
        return try {
            val source = appInfo.sourceDir ?: return 0L
            File(source).length().coerceAtLeast(0L)
        } catch (_: Exception) {
            0L
        }
    }

    private fun queryLastUsedMap(): Map<String, Long> {
        return try {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val start = end - (365L * 24L * 60L * 60L * 1000L)
            val stats = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)
            val map = HashMap<String, Long>(stats.size)
            for (item in stats) {
                val prev = map[item.packageName] ?: 0L
                if (item.lastTimeUsed > prev) {
                    map[item.packageName] = item.lastTimeUsed
                }
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }
}
