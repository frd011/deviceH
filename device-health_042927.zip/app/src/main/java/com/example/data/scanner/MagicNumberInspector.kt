package com.example.data.scanner

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.domain.model.DetectedFormat
import com.example.domain.model.MediaCategory
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream

data class MagicInspectionResult(
    val detectedFormat: DetectedFormat,
    val declaredExtension: String,
    val isObfuscatedExtension: Boolean,
    val magicHeaderHex: String,
    val durationMs: Long?
)

class MagicNumberInspector(private val context: Context) {

    fun inspectFile(file: File): MagicInspectionResult {
        val name = file.name
        val declaredExt = extractExtension(name)

        if (name.equals(".nomedia", ignoreCase = true) ||
            (file.length() == 0L && name.startsWith("."))
        ) {
            return MagicInspectionResult(
                detectedFormat = if (name.equals(".nomedia", ignoreCase = true)) {
                    DetectedFormat.NOMEDIA
                } else {
                    DetectedFormat.UNKNOWN
                },
                declaredExtension = declaredExt,
                isObfuscatedExtension = false,
                magicHeaderHex = if (file.length() == 0L) "00 (empty marker)" else "",
                durationMs = null
            )
        }

        val header = readHeaderBytes(file)
        val hexPreview = formatHexPreview(header)
        var detected = detectFromBytes(header, declaredExt)

        if (detected == DetectedFormat.ZIP) {
            if (isApkArchive(file) || declaredExt == "apk") {
                detected = DetectedFormat.APK
            }
        }

        var durationMs: Long? = null
        val shouldProbeMedia = detected.category == MediaCategory.VIDEO ||
            detected.category == MediaCategory.AUDIO ||
            (detected == DetectedFormat.UNKNOWN && file.length() > 4096L &&
                (name.startsWith(".") || declaredExt in SUSPICIOUS_EXTENSIONS || declaredExt.isEmpty()))

        if (shouldProbeMedia) {
            val mediaProbe = probeWithMediaMetadataRetriever(file.absolutePath, null)
            durationMs = mediaProbe.first
            if (detected == DetectedFormat.UNKNOWN && mediaProbe.second != null) {
                detected = mediaProbe.second!!
            }
        }

        val isObfuscated = computeIsObfuscated(declaredExt, detected)

        return MagicInspectionResult(
            detectedFormat = detected,
            declaredExtension = declaredExt,
            isObfuscatedExtension = isObfuscated,
            magicHeaderHex = hexPreview,
            durationMs = durationMs
        )
    }

    fun inspectUri(uri: Uri, displayName: String, sizeBytes: Long): MagicInspectionResult {
        val declaredExt = extractExtension(displayName)
        if (displayName.equals(".nomedia", ignoreCase = true)) {
            return MagicInspectionResult(
                detectedFormat = DetectedFormat.NOMEDIA,
                declaredExtension = declaredExt,
                isObfuscatedExtension = false,
                magicHeaderHex = "00 (marker)",
                durationMs = null
            )
        }

        val header = readHeaderBytesFromUri(uri)
        val hexPreview = formatHexPreview(header)
        var detected = detectFromBytes(header, declaredExt)

        if (detected == DetectedFormat.ZIP) {
            if (isApkArchiveFromUri(uri) || declaredExt == "apk") {
                detected = DetectedFormat.APK
            }
        }

        var durationMs: Long? = null
        val shouldProbeMedia = detected.category == MediaCategory.VIDEO ||
            detected.category == MediaCategory.AUDIO ||
            (detected == DetectedFormat.UNKNOWN && sizeBytes > 4096L &&
                (displayName.startsWith(".") || declaredExt in SUSPICIOUS_EXTENSIONS || declaredExt.isEmpty()))

        if (shouldProbeMedia) {
            val mediaProbe = probeWithMediaMetadataRetriever(null, uri)
            durationMs = mediaProbe.first
            if (detected == DetectedFormat.UNKNOWN && mediaProbe.second != null) {
                detected = mediaProbe.second!!
            }
        }

        val isObfuscated = computeIsObfuscated(declaredExt, detected)

        return MagicInspectionResult(
            detectedFormat = detected,
            declaredExtension = declaredExt,
            isObfuscatedExtension = isObfuscated,
            magicHeaderHex = hexPreview,
            durationMs = durationMs
        )
    }

    private fun extractExtension(name: String): String {
        val trimmed = if (name.startsWith(".")) name.substring(1) else name
        val dotIndex = trimmed.lastIndexOf('.')
        if (dotIndex <= 0 || dotIndex >= trimmed.length - 1) return ""
        return trimmed.substring(dotIndex + 1).lowercase(Locale.US)
    }

    private fun computeIsObfuscated(declaredExt: String, detected: DetectedFormat): Boolean {
        if (detected == DetectedFormat.UNKNOWN || detected == DetectedFormat.NOMEDIA) return false
        if (declaredExt.isEmpty()) return true
        return declaredExt !in detected.canonicalExtensions
    }

    private fun readHeaderBytes(file: File): ByteArray {
        return try {
            FileInputStream(file).use { input ->
                readFirstBytes(input, HEADER_READ_SIZE)
            }
        } catch (_: Exception) {
            ByteArray(0)
        }
    }

    private fun readHeaderBytesFromUri(uri: Uri): ByteArray {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                readFirstBytes(input, HEADER_READ_SIZE)
            } ?: ByteArray(0)
        } catch (_: Exception) {
            ByteArray(0)
        }
    }

    private fun readFirstBytes(input: InputStream, maxBytes: Int): ByteArray {
        val buffer = ByteArray(maxBytes)
        var totalRead = 0
        while (totalRead < maxBytes) {
            val read = input.read(buffer, totalRead, maxBytes - totalRead)
            if (read <= 0) break
            totalRead += read
        }
        return if (totalRead == maxBytes) buffer else buffer.copyOf(totalRead)
    }

    private fun formatHexPreview(bytes: ByteArray): String {
        if (bytes.isEmpty()) return "Unavailable"
        val limit = minOf(bytes.size, 12)
        return (0 until limit).joinToString(" ") { idx ->
            String.format(Locale.US, "%02X", bytes[idx].toInt() and 0xFF)
        }
    }

    internal fun detectFromBytes(header: ByteArray, declaredExt: String): DetectedFormat {
        if (header.size < 3) return fallbackFromExtension(declaredExt)

        // JPEG: FF D8 FF
        if (matches(header, 0, 0xFF, 0xD8, 0xFF)) {
            return DetectedFormat.JPG
        }

        // PNG: 89 50 4E 47 0D 0A 1A 0A
        if (header.size >= 8 && matches(header, 0, 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) {
            return DetectedFormat.PNG
        }

        // GIF: GIF87a / GIF89a
        if (header.size >= 6 &&
            matchesAscii(header, 0, "GIF8") &&
            (header[4] == '7'.code.toByte() || header[4] == '9'.code.toByte()) &&
            header[5] == 'a'.code.toByte()
        ) {
            return DetectedFormat.GIF
        }

        // RIFF container: WEBP / AVI / WAV
        if (header.size >= 12 && matchesAscii(header, 0, "RIFF")) {
            return when {
                matchesAscii(header, 8, "WEBP") -> DetectedFormat.WEBP
                matchesAscii(header, 8, "AVI ") -> DetectedFormat.AVI
                matchesAscii(header, 8, "WAVE") -> DetectedFormat.WAV
                else -> DetectedFormat.UNKNOWN
            }
        }

        // ISO Base Media File Format: "ftyp" at offset 4
        if (header.size >= 12 && matchesAscii(header, 4, "ftyp")) {
            val brand = asciiSlice(header, 8, 4)
            return when (brand) {
                "qt  " -> DetectedFormat.MOV
                "heic", "heix", "hevc", "hevx", "mif1", "msf1" -> DetectedFormat.HEIC
                "M4A ", "M4B ", "M4P " -> DetectedFormat.M4A
                "mp41", "mp42", "isom", "iso2", "iso5", "avc1", "3gp4", "3gp5", "3gp6", "mmp4", "mp71" -> DetectedFormat.MP4
                else -> if (declaredExt in DetectedFormat.MOV.canonicalExtensions) {
                    DetectedFormat.MOV
                } else if (declaredExt in DetectedFormat.M4A.canonicalExtensions) {
                    DetectedFormat.M4A
                } else {
                    DetectedFormat.MP4
                }
            }
        }

        // EBML (MKV / WebM): 1A 45 DF A3
        if (header.size >= 4 && matches(header, 0, 0x1A, 0x45, 0xDF, 0xA3)) {
            val ascii = header.decodeToString().lowercase(Locale.US)
            return if (ascii.contains("webm")) DetectedFormat.WEBM else DetectedFormat.MKV
        }

        // MP3 (ID3 tag or raw MPEG frame sync)
        if (matchesAscii(header, 0, "ID3") ||
            matches(header, 0, 0xFF, 0xFB) ||
            matches(header, 0, 0xFF, 0xF3) ||
            matches(header, 0, 0xFF, 0xF2) ||
            matches(header, 0, 0xFF, 0xFA)
        ) {
            return DetectedFormat.MP3
        }

        // FLAC: fLaC
        if (header.size >= 4 && matchesAscii(header, 0, "fLaC")) {
            return DetectedFormat.FLAC
        }

        // OGG: OggS
        if (header.size >= 4 && matchesAscii(header, 0, "OggS")) {
            return DetectedFormat.OGG
        }

        // ZIP / APK: 50 4B 03 04 or 50 4B 05 06
        if (header.size >= 4 &&
            (matches(header, 0, 0x50, 0x4B, 0x03, 0x04) || matches(header, 0, 0x50, 0x4B, 0x05, 0x06))
        ) {
            return DetectedFormat.ZIP
        }

        // RAR: Rar!
        if (header.size >= 6 && matches(header, 0, 0x52, 0x61, 0x72, 0x21, 0x1A, 0x07)) {
            return DetectedFormat.RAR
        }

        // 7-Zip: 37 7A BC AF 27 1C
        if (header.size >= 6 && matches(header, 0, 0x37, 0x7A, 0xBC, 0xAF, 0x27, 0x1C)) {
            return DetectedFormat.SEVEN_Z
        }

        // PDF: %PDF
        if (header.size >= 4 && matchesAscii(header, 0, "%PDF")) {
            return DetectedFormat.PDF
        }

        return DetectedFormat.UNKNOWN
    }

    private fun fallbackFromExtension(ext: String): DetectedFormat {
        if (ext.isEmpty()) return DetectedFormat.UNKNOWN
        return DetectedFormat.entries.firstOrNull { ext in it.canonicalExtensions } ?: DetectedFormat.UNKNOWN
    }

    private fun isApkArchive(file: File): Boolean {
        return try {
            FileInputStream(file).use { stream ->
                hasApkEntries(stream)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun isApkArchiveFromUri(uri: Uri): Boolean {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                hasApkEntries(stream)
            } ?: false
        } catch (_: Exception) {
            false
        }
    }

    private fun hasApkEntries(inputStream: InputStream): Boolean {
        ZipInputStream(BufferedInputStream(inputStream)).use { zip ->
            var inspected = 0
            var entry = zip.nextEntry
            while (entry != null && inspected < 30) {
                val entryName = entry.name
                if (entryName == "AndroidManifest.xml" || entryName == "classes.dex") {
                    return true
                }
                inspected++
                entry = zip.nextEntry
            }
        }
        return false
    }

    private fun probeWithMediaMetadataRetriever(
        filePath: String?,
        uri: Uri?
    ): Pair<Long?, DetectedFormat?> {
        val retriever = MediaMetadataRetriever()
        return try {
            when {
                filePath != null -> retriever.setDataSource(filePath)
                uri != null -> retriever.setDataSource(context, uri)
                else -> return null to null
            }
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
            val mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
                ?.lowercase(Locale.US)
            val inferred = when {
                mime == null -> null
                mime.contains("mp4") -> DetectedFormat.MP4
                mime.contains("matroska") || mime.contains("mkv") -> DetectedFormat.MKV
                mime.contains("webm") -> DetectedFormat.WEBM
                mime.contains("quicktime") -> DetectedFormat.MOV
                mime.contains("avi") -> DetectedFormat.AVI
                mime.contains("mpeg") || mime.contains("mp3") -> DetectedFormat.MP3
                mime.contains("flac") -> DetectedFormat.FLAC
                mime.contains("ogg") -> DetectedFormat.OGG
                mime.contains("wav") -> DetectedFormat.WAV
                mime.startsWith("video/") -> DetectedFormat.MP4
                mime.startsWith("audio/") -> DetectedFormat.M4A
                else -> null
            }
            durationMs to inferred
        } catch (_: Exception) {
            null to null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun matches(bytes: ByteArray, offset: Int, vararg expected: Int): Boolean {
        if (bytes.size < offset + expected.size) return false
        for (i in expected.indices) {
            if ((bytes[offset + i].toInt() and 0xFF) != expected[i]) return false
        }
        return true
    }

    private fun matchesAscii(bytes: ByteArray, offset: Int, text: String): Boolean {
        if (bytes.size < offset + text.length) return false
        for (i in text.indices) {
            if (bytes[offset + i].toInt().toChar() != text[i]) return false
        }
        return true
    }

    private fun asciiSlice(bytes: ByteArray, offset: Int, length: Int): String {
        if (bytes.size < offset + length) return ""
        return String(bytes, offset, length, Charsets.US_ASCII)
    }

    companion object {
        private const val HEADER_READ_SIZE = 256
        private val SUSPICIOUS_EXTENSIONS = setOf(
            "tmp", "temp", "bin", "dat", "cache", "exo", "chk", "bak", "hidden", "obf"
        )
    }
}
