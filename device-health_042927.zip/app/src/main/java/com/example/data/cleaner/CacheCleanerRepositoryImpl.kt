package com.example.data.cleaner

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import androidx.core.content.ContextCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.AppCacheGuideItem
import com.example.domain.model.CleanableTarget
import com.example.domain.model.CleanableTargetType
import com.example.domain.model.CleanerOverview
import com.example.domain.model.DeletionResult
import com.example.domain.model.SafLocationSummary
import com.example.domain.model.StorageAccessMode
import com.example.domain.repository.AppManagerRepository
import com.example.domain.repository.CacheCleanerRepository
import java.io.File
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

private val Context.cleanerDataStore: DataStore<Preferences> by preferencesDataStore(name = "cleaner_prefs")

class CacheCleanerRepositoryImpl(
    private val context: Context,
    private val appManagerRepository: AppManagerRepository
) : CacheCleanerRepository {

    private val safUrisKey = stringSetPreferencesKey("persisted_saf_tree_uris")
    private val clearedAppsKey = stringSetPreferencesKey("guided_cleared_apps")

    override fun getStorageAccessMode(): StorageAccessMode {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            when {
                Environment.isExternalStorageManager() -> StorageAccessMode.FULL_STORAGE_GRANTED
                getPersistedSafUris().isNotEmpty() -> StorageAccessMode.SAF_ONLY
                else -> StorageAccessMode.NEEDS_PERMISSION
            }
        } else {
            val hasRead = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            val hasWrite = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
            if (hasRead && hasWrite) {
                StorageAccessMode.LEGACY_STORAGE_GRANTED
            } else {
                StorageAccessMode.NEEDS_PERMISSION
            }
        }
    }

    override fun getPersistedSafUris(): List<Uri> {
        return context.contentResolver.persistedUriPermissions
            .filter { it.isReadPermission && it.isWritePermission }
            .map { it.uri }
    }

    override suspend fun persistSafTreeUri(uri: Uri) = withContext(Dispatchers.IO) {
        try {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
        } catch (_: Exception) {
        }
        context.cleanerDataStore.edit { prefs ->
            val current = prefs[safUrisKey] ?: emptySet()
            prefs[safUrisKey] = current + uri.toString()
        }
        Unit
    }

    override suspend fun removeSafTreeUri(uri: Uri) = withContext(Dispatchers.IO) {
        try {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.releasePersistableUriPermission(uri, flags)
        } catch (_: Exception) {
        }
        context.cleanerDataStore.edit { prefs ->
            val current = prefs[safUrisKey] ?: emptySet()
            prefs[safUrisKey] = current - uri.toString()
        }
        Unit
    }

    override suspend fun markAppCacheReviewed(packageName: String) {
        context.cleanerDataStore.edit { prefs ->
            val current = prefs[clearedAppsKey] ?: emptySet()
            prefs[clearedAppsKey] = current + packageName
        }
    }

    override suspend fun analyzeCleanerOverview(): CleanerOverview = withContext(Dispatchers.IO) {
        val accessMode = getStorageAccessMode()
        val androidLabel = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        val targets = ArrayList<CleanableTarget>()

        // 1. Direct filesystem targets when All Files or Legacy Storage is available
        val root = Environment.getExternalStorageDirectory()
        if (root != null && root.exists() && root.canRead() &&
            (accessMode == StorageAccessMode.FULL_STORAGE_GRANTED ||
                accessMode == StorageAccessMode.LEGACY_STORAGE_GRANTED)
        ) {
            val thumbPaths = ArrayList<String>()
            var thumbBytes = 0L

            val tempPaths = ArrayList<String>()
            var tempBytes = 0L

            val emptyDirs = ArrayList<String>()

            val stack = ArrayDeque<File>()
            stack.addLast(root)
            while (stack.isNotEmpty()) {
                val dir = stack.removeLast()
                val children = dir.listFiles() ?: continue
                if (children.isEmpty() && dir != root && !dir.name.equals("Android", ignoreCase = true)) {
                    emptyDirs.add(dir.absolutePath)
                    continue
                }
                val isThumbDir = dir.name.equals(".thumbnails", ignoreCase = true)
                for (child in children) {
                    if (child.isDirectory) {
                        stack.addLast(child)
                    } else if (child.isFile) {
                        val size = child.length().coerceAtLeast(0L)
                        if (isThumbDir) {
                            thumbPaths.add(child.absolutePath)
                            thumbBytes += size
                        } else {
                            val lower = child.name.lowercase(Locale.US)
                            if (TEMP_EXTENSIONS.any { lower.endsWith(it) }) {
                                tempPaths.add(child.absolutePath)
                                tempBytes += size
                            }
                        }
                    }
                }
            }

            if (thumbPaths.isNotEmpty()) {
                targets.add(
                    CleanableTarget(
                        id = "hidden_thumbnails",
                        title = "Hidden Media Thumbnails",
                        subtitle = ".thumbnails caches across DCIM, Pictures & Movies",
                        pathOrUri = "${thumbPaths.size} cached thumbnails",
                        sizeBytes = thumbBytes,
                        itemCount = thumbPaths.size,
                        type = CleanableTargetType.HIDDEN_THUMBNAILS,
                        pathsToDelete = thumbPaths
                    )
                )
            }

            if (tempPaths.isNotEmpty()) {
                targets.add(
                    CleanableTarget(
                        id = "temp_and_logs",
                        title = "Residual Temp & Log Files",
                        subtitle = ".tmp, .temp, .log, .exo & crash artifacts",
                        pathOrUri = "${tempPaths.size} residual files",
                        sizeBytes = tempBytes,
                        itemCount = tempPaths.size,
                        type = CleanableTargetType.TEMP_AND_LOGS,
                        pathsToDelete = tempPaths
                    )
                )
            }

            if (emptyDirs.isNotEmpty()) {
                targets.add(
                    CleanableTarget(
                        id = "empty_dirs",
                        title = "Empty Residual Folders",
                        subtitle = "Orphaned directories left after app uninstalls",
                        pathOrUri = "${emptyDirs.size} empty folders",
                        sizeBytes = 0L,
                        itemCount = emptyDirs.size,
                        type = CleanableTargetType.EMPTY_DIRECTORIES,
                        pathsToDelete = emptyDirs
                    )
                )
            }
        }

        // 2. Scan persisted SAF DocumentTree folders (Android 11+ Scoped Storage workflow)
        val safSummaries = ArrayList<SafLocationSummary>()
        for (treeUri in getPersistedSafUris()) {
            val safScan = scanSafTreeForCache(treeUri)
            safSummaries.add(safScan.first)
            if (safScan.second.isNotEmpty()) {
                targets.add(
                    CleanableTarget(
                        id = "saf_${treeUri}",
                        title = "SAF Cache: ${safScan.first.displayName}",
                        subtitle = "Accessible via Storage Access Framework",
                        pathOrUri = treeUri.toString(),
                        sizeBytes = safScan.first.cacheBytes,
                        itemCount = safScan.second.size,
                        type = CleanableTargetType.SAF_CACHE_FOLDER,
                        safDocumentUris = safScan.second
                    )
                )
            }
        }

        // 3. Guided App Cache Helper for OS-restricted /Android/data on Android 11+
        val hasUsageStats = appManagerRepository.hasUsageStatsPermission()
        val reviewedSet = context.cleanerDataStore.data.first()[clearedAppsKey] ?: emptySet()
        val apps = appManagerRepository.loadInstalledApps()
        val appGuides = apps
            .filter { !it.isSystemApp || it.cacheBytes > 2 * 1024 * 1024L }
            .sortedWith(compareByDescending<com.example.domain.model.InstalledAppInfo> { it.cacheBytes }.thenByDescending { it.totalBytes })
            .take(15)
            .map {
                AppCacheGuideItem(
                    packageName = it.packageName,
                    appName = it.appName,
                    cacheBytes = it.cacheBytes,
                    isMarkedCleared = it.packageName in reviewedSet
                )
            }

        CleanerOverview(
            accessMode = accessMode,
            androidVersionLabel = androidLabel,
            targets = targets,
            safLocations = safSummaries,
            appCacheGuides = appGuides,
            hasUsageStatsAccess = hasUsageStats
        )
    }

    override suspend fun cleanTargets(targets: List<CleanableTarget>): DeletionResult = withContext(Dispatchers.IO) {
        var deletedCount = 0
        var failedCount = 0
        var freedBytes = 0L
        val deletedIds = HashSet<String>()

        for (target in targets) {
            var targetSuccess = true
            for (path in target.pathsToDelete) {
                val file = File(path)
                val size = if (file.isFile) file.length().coerceAtLeast(0L) else 0L
                val ok = try {
                    !file.exists() || file.delete()
                } catch (_: Exception) {
                    false
                }
                if (ok) {
                    deletedCount++
                    freedBytes += size
                } else {
                    failedCount++
                    targetSuccess = false
                }
            }

            for (uriStr in target.safDocumentUris) {
                val ok = try {
                    DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(uriStr))
                } catch (_: Exception) {
                    false
                }
                if (ok) {
                    deletedCount++
                } else {
                    failedCount++
                    targetSuccess = false
                }
            }

            if (target.safDocumentUris.isNotEmpty() && targetSuccess) {
                freedBytes += target.sizeBytes
            }
            if (targetSuccess) {
                deletedIds.add(target.id)
            }
        }

        DeletionResult(
            deletedCount = deletedCount,
            failedCount = failedCount,
            freedBytes = freedBytes,
            deletedIds = deletedIds
        )
    }

    private fun scanSafTreeForCache(treeUri: Uri): Pair<SafLocationSummary, List<String>> {
        val docUris = ArrayList<String>()
        var totalBytes = 0L
        val rootDocId = try {
            DocumentsContract.getTreeDocumentId(treeUri)
        } catch (_: Exception) {
            return SafLocationSummary(treeUri.toString(), treeUri.lastPathSegment ?: "Folder", 0, 0L) to emptyList()
        }

        val displayName = rootDocId.substringAfter(':').ifEmpty { "Selected Folder" }
        val stack = ArrayDeque<Pair<String, Boolean>>()
        stack.addLast(rootDocId to false)
        var visited = 0

        while (stack.isNotEmpty() && visited < 400) {
            val (docId, insideCacheDir) = stack.removeLast()
            visited++
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE
            )
            try {
                context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                    val sizeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)

                    while (cursor.moveToNext()) {
                        val childId = cursor.getString(idCol) ?: continue
                        val name = cursor.getString(nameCol) ?: ""
                        val mime = cursor.getString(mimeCol) ?: ""
                        val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                        val lower = name.lowercase(Locale.US)

                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            val isCacheFolder = insideCacheDir ||
                                lower == "cache" ||
                                lower == "code_cache" ||
                                lower == ".thumbnails" ||
                                lower == "temp"
                            stack.addLast(childId to isCacheFolder)
                        } else if (insideCacheDir || TEMP_EXTENSIONS.any { lower.endsWith(it) }) {
                            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                            docUris.add(docUri.toString())
                            totalBytes += size
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        return SafLocationSummary(
            treeUri = treeUri.toString(),
            displayName = displayName,
            cacheCandidateCount = docUris.size,
            cacheBytes = totalBytes
        ) to docUris
    }

    companion object {
        private val TEMP_EXTENSIONS = listOf(".tmp", ".temp", ".log", ".bak", ".exo")
    }
}
