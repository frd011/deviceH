package com.example.data.scanner

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import com.example.domain.model.DeletionResult
import com.example.domain.model.FormatBreakdown
import com.example.domain.model.ScanProgressState
import com.example.domain.model.ScannedFileItem
import com.example.domain.repository.FileScannerRepository
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

class FileScannerRepositoryImpl(
    private val context: Context,
    private val inspector: MagicNumberInspector
) : FileScannerRepository {

    override fun scanInternalStorage(safTreeUris: List<Uri>): Flow<ScanProgressState> = flow {
        val startTime = System.currentTimeMillis()
        val scannedFiles = ArrayList<ScannedFileItem>(512)
        val seenPaths = HashSet<String>(512)
        var totalBytes = 0L
        var hiddenCount = 0
        var obfuscatedCount = 0
        var lastEmitTime = 0L

        val rootDir = Environment.getExternalStorageDirectory()
        if (rootDir != null && rootDir.exists() && rootDir.canRead()) {
            val stack = ArrayDeque<Pair<File, Boolean>>()
            stack.addLast(rootDir to false)

            while (stack.isNotEmpty()) {
                currentCoroutineContext().ensureActive()
                val (currentDir, parentIsHidden) = stack.removeLast()
                val dirIsHidden = parentIsHidden || currentDir.name.startsWith(".")

                val children = currentDir.listFiles() ?: continue
                for (child in children) {
                    currentCoroutineContext().ensureActive()
                    if (child.isDirectory) {
                        // Avoid symlink loops by skipping canonical cycles if obvious
                        stack.addLast(child to dirIsHidden)
                    } else if (child.isFile) {
                        val path = child.absolutePath
                        if (!seenPaths.add(path)) continue

                        val isDotFile = child.name.startsWith(".")
                        val inspection = inspector.inspectFile(child)
                        val size = child.length().coerceAtLeast(0L)

                        val item = ScannedFileItem(
                            id = path,
                            name = child.name,
                            path = path,
                            uriString = null,
                            sizeBytes = size,
                            lastModifiedMs = child.lastModified(),
                            isHiddenDotFile = isDotFile,
                            isInsideHiddenFolder = dirIsHidden,
                            declaredExtension = inspection.declaredExtension,
                            detectedFormat = inspection.detectedFormat,
                            isObfuscatedExtension = inspection.isObfuscatedExtension,
                            magicHeaderHex = inspection.magicHeaderHex,
                            durationMs = inspection.durationMs
                        )
                        scannedFiles.add(item)
                        totalBytes += size
                        if (item.isHidden) hiddenCount++
                        if (item.isObfuscatedExtension) obfuscatedCount++

                        val now = System.currentTimeMillis()
                        if (scannedFiles.size % 35 == 0 || now - lastEmitTime >= 110L) {
                            lastEmitTime = now
                            emit(
                                ScanProgressState.Scanning(
                                    scannedFilesCount = scannedFiles.size,
                                    scannedBytes = totalBytes,
                                    hiddenFilesCount = hiddenCount,
                                    obfuscatedCount = obfuscatedCount,
                                    currentDirectory = currentDir.name.ifEmpty { "/" }
                                )
                            )
                        }
                    }
                }
            }
        }

        // Also scan any persisted SAF DocumentTree URIs (useful on Android 11+ without All Files Access or for /Android/data)
        for (treeUri in safTreeUris) {
            currentCoroutineContext().ensureActive()
            val rootDocId = try {
                DocumentsContract.getTreeDocumentId(treeUri)
            } catch (_: Exception) {
                continue
            }
            val safStack = ArrayDeque<Triple<String, String, Boolean>>()
            safStack.addLast(Triple(rootDocId, treeUri.lastPathSegment ?: "SAF", false))

            while (safStack.isNotEmpty()) {
                currentCoroutineContext().ensureActive()
                val (docId, folderPath, parentHidden) = safStack.removeLast()
                val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
                val projection = arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                )
                try {
                    context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                        val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                        val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                        val mimeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                        val sizeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                        val modCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_LAST_MODIFIED)

                        while (cursor.moveToNext()) {
                            currentCoroutineContext().ensureActive()
                            val childId = cursor.getString(idCol) ?: continue
                            val name = cursor.getString(nameCol) ?: "unknown"
                            val mime = cursor.getString(mimeCol) ?: ""
                            val size = cursor.getLong(sizeCol).coerceAtLeast(0L)
                            val modified = cursor.getLong(modCol)

                            if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                                val nextHidden = parentHidden || name.startsWith(".")
                                safStack.addLast(Triple(childId, "$folderPath/$name", nextHidden))
                            } else {
                                val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                                val uniqueKey = docUri.toString()
                                if (!seenPaths.add(uniqueKey)) continue

                                val isDotFile = name.startsWith(".")
                                val inspection = inspector.inspectUri(docUri, name, size)
                                val item = ScannedFileItem(
                                    id = uniqueKey,
                                    name = name,
                                    path = "$folderPath/$name",
                                    uriString = uniqueKey,
                                    sizeBytes = size,
                                    lastModifiedMs = modified,
                                    isHiddenDotFile = isDotFile,
                                    isInsideHiddenFolder = parentHidden,
                                    declaredExtension = inspection.declaredExtension,
                                    detectedFormat = inspection.detectedFormat,
                                    isObfuscatedExtension = inspection.isObfuscatedExtension,
                                    magicHeaderHex = inspection.magicHeaderHex,
                                    durationMs = inspection.durationMs
                                )
                                scannedFiles.add(item)
                                totalBytes += size
                                if (item.isHidden) hiddenCount++
                                if (item.isObfuscatedExtension) obfuscatedCount++

                                val now = System.currentTimeMillis()
                                if (scannedFiles.size % 25 == 0 || now - lastEmitTime >= 110L) {
                                    lastEmitTime = now
                                    emit(
                                        ScanProgressState.Scanning(
                                            scannedFilesCount = scannedFiles.size,
                                            scannedBytes = totalBytes,
                                            hiddenFilesCount = hiddenCount,
                                            obfuscatedCount = obfuscatedCount,
                                            currentDirectory = folderPath
                                        )
                                    )
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                    // SAF permission may have been revoked; skip safely
                }
            }
        }

        val sortedFiles = scannedFiles.sortedByDescending { it.sizeBytes }
        val breakdowns = sortedFiles
            .groupBy { it.detectedFormat }
            .map { (format, group) ->
                FormatBreakdown(
                    format = format,
                    count = group.size,
                    totalBytes = group.sumOf { it.sizeBytes }
                )
            }
            .sortedByDescending { it.totalBytes }

        val elapsed = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
        emit(
            ScanProgressState.Completed(
                files = sortedFiles,
                totalBytes = totalBytes,
                hiddenCount = hiddenCount,
                obfuscatedCount = obfuscatedCount,
                formatBreakdowns = breakdowns,
                durationMs = elapsed
            )
        )
    }.flowOn(Dispatchers.IO)

    override suspend fun deleteFiles(items: List<ScannedFileItem>): DeletionResult = withContext(Dispatchers.IO) {
        var deletedCount = 0
        var failedCount = 0
        var freedBytes = 0L
        val deletedIds = HashSet<String>()

        for (item in items) {
            val deleted = if (item.uriString != null) {
                try {
                    DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(item.uriString))
                } catch (_: Exception) {
                    false
                }
            } else {
                try {
                    val file = File(item.path)
                    !file.exists() || file.delete()
                } catch (_: Exception) {
                    false
                }
            }

            if (deleted) {
                deletedCount++
                freedBytes += item.sizeBytes
                deletedIds.add(item.id)
            } else {
                failedCount++
            }
        }

        DeletionResult(
            deletedCount = deletedCount,
            failedCount = failedCount,
            freedBytes = freedBytes,
            deletedIds = deletedIds
        )
    }
}
