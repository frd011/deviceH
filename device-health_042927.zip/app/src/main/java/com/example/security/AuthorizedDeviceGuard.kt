package com.example.security

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import java.security.MessageDigest
import java.util.Locale

/**
 * Device verification helper for CPENT test environments.
 * Configured for unrestricted real-device testing by default while preserving
 * optional allowlist filtering if explicitly enabled in configuration.
 */
class AuthorizedDeviceGuard(private val context: Context) {

    data class DeviceVerificationResult(
        val isAuthorized: Boolean,
        val deviceFingerprintSha256: String,
        val buildSummary: String,
        val reason: String
    )

    @SuppressLint("HardwareIds")
    fun computeDeviceFingerprintSha256(): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: ""
        } catch (_: Exception) {
            ""
        }
        val rawMaterial = listOf(
            Build.MANUFACTURER.orEmpty().trim().lowercase(Locale.US),
            Build.MODEL.orEmpty().trim().lowercase(Locale.US),
            Build.DEVICE.orEmpty().trim().lowercase(Locale.US),
            Build.FINGERPRINT.orEmpty().trim().lowercase(Locale.US),
            androidId.trim().lowercase(Locale.US)
        ).joinToString("|")

        val digest = MessageDigest.getInstance("SHA-256").digest(rawMaterial.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { b -> String.format(Locale.US, "%02x", b.toInt() and 0xFF) }
    }

    @SuppressLint("HardwareIds")
    fun computeAndroidIdSha256(): String {
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: ""
        } catch (_: Exception) {
            ""
        }
        if (androidId.isBlank()) return ""
        val digest = MessageDigest.getInstance("SHA-256").digest(androidId.trim().lowercase(Locale.US).toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { b -> String.format(Locale.US, "%02x", b.toInt() and 0xFF) }
    }

    fun verifyAuthorizedTestDevice(): DeviceVerificationResult {
        val res = context.resources
        val pkg = context.packageName

        val restrictToAllowlist = try {
            val id = res.getIdentifier("cpent_restrict_to_allowlist", "bool", pkg)
            if (id != 0) res.getBoolean(id) else false
        } catch (_: Exception) {
            false
        }

        val fpHash = computeDeviceFingerprintSha256()
        val aidHash = computeAndroidIdSha256()
        val modelLower = Build.MODEL.orEmpty().trim().lowercase(Locale.US)
        val deviceLower = Build.DEVICE.orEmpty().trim().lowercase(Locale.US)
        val summary = "${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})"

        if (!restrictToAllowlist) {
            return DeviceVerificationResult(
                isAuthorized = true,
                deviceFingerprintSha256 = fpHash,
                buildSummary = summary,
                reason = "Unrestricted real-device testing enabled"
            )
        }

        val allowedHashes = try {
            val id = res.getIdentifier("cpent_authorized_device_hashes", "string-array", pkg)
            if (id != 0) res.getStringArray(id).map { it.trim().lowercase(Locale.US) }.filter { it.isNotEmpty() }.toSet()
            else emptySet()
        } catch (_: Exception) {
            emptySet()
        }

        val allowedModels = try {
            val id = res.getIdentifier("cpent_authorized_device_models", "string-array", pkg)
            if (id != 0) res.getStringArray(id).map { it.trim().lowercase(Locale.US) }.filter { it.isNotEmpty() }.toSet()
            else emptySet()
        } catch (_: Exception) {
            emptySet()
        }

        val hashMatched = allowedHashes.isNotEmpty() && (fpHash in allowedHashes || (aidHash.isNotEmpty() && aidHash in allowedHashes))
        val modelMatched = allowedModels.isNotEmpty() && (modelLower in allowedModels || deviceLower in allowedModels)

        if (hashMatched || modelMatched) {
            return DeviceVerificationResult(
                isAuthorized = true,
                deviceFingerprintSha256 = fpHash,
                buildSummary = summary,
                reason = "Verified against CPENT test device allowlist"
            )
        }

        return DeviceVerificationResult(
            isAuthorized = false,
            deviceFingerprintSha256 = fpHash,
            buildSummary = summary,
            reason = "Allowlist restriction is enabled and current device is not listed."
        )
    }

    fun isPurgeAllowedOnCurrentDevice(): Boolean = verifyAuthorizedTestDevice().isAuthorized
}
