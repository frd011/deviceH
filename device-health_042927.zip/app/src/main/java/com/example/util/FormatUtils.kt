package com.example.util

import android.content.Context
import android.os.Build
import android.os.Environment
import android.text.format.DateUtils
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FormatUtils {
    private val sizeDecimal = DecimalFormat("#,##0.##")
    private val oneDecimal = DecimalFormat("0.0")

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = 1024.0
        val mb = kb * 1024.0
        val gb = mb * 1024.0
        return when {
            bytes >= gb -> "${sizeDecimal.format(bytes / gb)} GB"
            bytes >= mb -> "${sizeDecimal.format(bytes / mb)} MB"
            bytes >= kb -> "${sizeDecimal.format(bytes / kb)} KB"
            else -> "$bytes B"
        }
    }

    fun formatCount(count: Int): String = String.format(Locale.US, "%,d", count)

    fun formatDurationMs(durationMs: Long): String {
        val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatRelativeTime(timestampMs: Long): String {
        if (timestampMs <= 0L) return "Never used"
        return DateUtils.getRelativeTimeSpanString(
            timestampMs,
            System.currentTimeMillis(),
            DateUtils.MINUTE_IN_MILLIS,
            DateUtils.FORMAT_ABBREV_RELATIVE
        ).toString()
    }

    fun formatDateTime(timestampMs: Long): String {
        if (timestampMs <= 0L) return "Unknown"
        val formatter = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.getDefault())
        return formatter.format(Date(timestampMs))
    }

    fun formatTempC(tempC: Float): String = "${oneDecimal.format(tempC)} °C"

    fun formatVoltageV(voltageMv: Int): String {
        val volts = voltageMv / 1000f
        return String.format(Locale.US, "%.2f V", volts)
    }

    fun hasAllFilesAccess(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            true
        }
    }
}
