package com.example.domain.usecase

import com.example.domain.model.InstalledAppInfo
import com.example.domain.repository.AppManagerRepository

class LoadInstalledAppsUseCase(
    private val repository: AppManagerRepository
) {
    suspend operator fun invoke(): List<InstalledAppInfo> = repository.loadInstalledApps()
}
