package com.example.domain.repository

import android.net.Uri
import com.example.domain.model.CleanableTarget
import com.example.domain.model.CleanerOverview
import com.example.domain.model.DeletionResult
import com.example.domain.model.StorageAccessMode

interface CacheCleanerRepository {
    fun getStorageAccessMode(): StorageAccessMode
    fun getPersistedSafUris(): List<Uri>
    suspend fun persistSafTreeUri(uri: Uri)
    suspend fun removeSafTreeUri(uri: Uri)
    suspend fun analyzeCleanerOverview(): CleanerOverview
    suspend fun cleanTargets(targets: List<CleanableTarget>): DeletionResult
    suspend fun markAppCacheReviewed(packageName: String)
}
