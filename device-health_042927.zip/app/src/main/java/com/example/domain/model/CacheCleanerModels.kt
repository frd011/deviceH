package com.example.domain.model

enum class StorageAccessMode {
    FULL_STORAGE_GRANTED,
    LEGACY_STORAGE_GRANTED,
    SAF_ONLY,
    NEEDS_PERMISSION
}

enum class CleanableTargetType {
    HIDDEN_THUMBNAILS,
    TEMP_AND_LOGS,
    EMPTY_DIRECTORIES,
    SAF_CACHE_FOLDER
}

data class CleanableTarget(
    val id: String,
    val title: String,
    val subtitle: String,
    val pathOrUri: String,
    val sizeBytes: Long,
    val itemCount: Int,
    val type: CleanableTargetType,
    val pathsToDelete: List<String> = emptyList(),
    val safDocumentUris: List<String> = emptyList()
)

data class SafLocationSummary(
    val treeUri: String,
    val displayName: String,
    val cacheCandidateCount: Int,
    val cacheBytes: Long
)

data class AppCacheGuideItem(
    val packageName: String,
    val appName: String,
    val cacheBytes: Long,
    val isMarkedCleared: Boolean = false
)

data class CleanerOverview(
    val accessMode: StorageAccessMode,
    val androidVersionLabel: String,
    val targets: List<CleanableTarget>,
    val safLocations: List<SafLocationSummary>,
    val appCacheGuides: List<AppCacheGuideItem>,
    val hasUsageStatsAccess: Boolean
)
