package com.example.domain.repository

import android.net.Uri
import com.example.domain.model.DeletionResult
import com.example.domain.model.ScanProgressState
import com.example.domain.model.ScannedFileItem
import kotlinx.coroutines.flow.Flow

interface FileScannerRepository {
    fun scanInternalStorage(safTreeUris: List<Uri>): Flow<ScanProgressState>
    suspend fun deleteFiles(items: List<ScannedFileItem>): DeletionResult
}
