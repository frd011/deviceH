package com.example.domain.model

enum class HealthEstimationMethod(val label: String) {
    KERNEL_CHARGE_FULL("Kernel Sysfs Gauge"),
    CHARGE_COUNTER_SESSION("Charge Counter Calibration"),
    SESSION_HISTORY_FALLBACK("Session Delta Estimate")
}

enum class BatteryCondition {
    HEALTHY,
    MODERATE,
    DEGRADED
}

data class ChargingSessionRecord(
    val id: String,
    val timestampMs: Long,
    val startLevel: Int,
    val endLevel: Int,
    val deltaMah: Int,
    val estimatedFullMah: Int,
    val avgTempC: Float
)

data class BatteryStatusSnapshot(
    val levelPercent: Int,
    val isCharging: Boolean,
    val chargeSource: String,
    val chargingStatusLabel: String,
    val voltageMv: Int,
    val temperatureC: Float,
    val currentNowMa: Int,
    val powerWatts: Float,
    val technology: String,
    val osHealthLabel: String,
    val cycleCount: Int?,
    val chargeCounterMah: Int?,
    val designCapacityMah: Int,
    val estimatedFullCapacityMah: Int,
    val estimatedHealthPercent: Int,
    val condition: BatteryCondition,
    val estimationMethod: HealthEstimationMethod,
    val isCustomDesignCapacity: Boolean,
    val recentSessions: List<ChargingSessionRecord>,
    val timestampMs: Long
)
