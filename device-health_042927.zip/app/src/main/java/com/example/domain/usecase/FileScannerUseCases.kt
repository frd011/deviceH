package com.example.domain.usecase

import android.net.Uri
import com.example.domain.model.DeletionResult
import com.example.domain.model.ScanProgressState
import com.example.domain.model.ScannedFileItem
import com.example.domain.repository.FileScannerRepository
import kotlinx.coroutines.flow.Flow

class ScanStorageUseCase(
    private val repository: FileScannerRepository
) {
    operator fun invoke(safTreeUris: List<Uri> = emptyList()): Flow<ScanProgressState> =
        repository.scanInternalStorage(safTreeUris)
}

class DeleteScannedFilesUseCase(
    private val repository: FileScannerRepository
) {
    suspend operator fun invoke(items: List<ScannedFileItem>): DeletionResult =
        repository.deleteFiles(items)
}
