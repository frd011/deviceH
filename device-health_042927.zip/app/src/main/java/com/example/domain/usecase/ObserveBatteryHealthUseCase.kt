package com.example.domain.usecase

import com.example.domain.model.BatteryStatusSnapshot
import com.example.domain.repository.BatteryRepository
import kotlinx.coroutines.flow.Flow

class ObserveBatteryHealthUseCase(
    private val repository: BatteryRepository
) {
    operator fun invoke(): Flow<BatteryStatusSnapshot> = repository.observeBatteryHealth()
}
