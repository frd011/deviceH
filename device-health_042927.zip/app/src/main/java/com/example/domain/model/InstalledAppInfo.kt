package com.example.domain.model

enum class AppSortOption(val label: String) {
    TOTAL_SIZE("Total Size"),
    CACHE_SIZE("Cache Size"),
    LAST_USED("Last Used"),
    NAME("Name (A-Z)")
}

enum class AppCategoryFilter(val label: String) {
    USER("User Apps"),
    SYSTEM("System Apps"),
    ALL("All Apps")
}

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isSystemApp: Boolean,
    val appBytes: Long,
    val dataBytes: Long,
    val cacheBytes: Long,
    val totalBytes: Long,
    val lastUsedMs: Long,
    val canUninstall: Boolean
)
