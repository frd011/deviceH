package com.example.domain.repository

import com.example.domain.model.InstalledAppInfo

interface AppManagerRepository {
    fun hasUsageStatsPermission(): Boolean
    suspend fun loadInstalledApps(): List<InstalledAppInfo>
}
