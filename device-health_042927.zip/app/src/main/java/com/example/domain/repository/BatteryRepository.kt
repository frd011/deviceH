package com.example.domain.repository

import com.example.domain.model.BatteryStatusSnapshot
import kotlinx.coroutines.flow.Flow

interface BatteryRepository {
    fun observeBatteryHealth(): Flow<BatteryStatusSnapshot>
    suspend fun setCustomDesignCapacityMah(capacityMah: Int?)
    suspend fun clearSessionHistory()
}
