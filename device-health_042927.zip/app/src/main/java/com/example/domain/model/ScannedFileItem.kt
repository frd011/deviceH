package com.example.domain.model

enum class MediaCategory(val displayName: String) {
    VIDEO("Video"),
    IMAGE("Image"),
    AUDIO("Audio"),
    APK("APK"),
    ARCHIVE("Archive"),
    DOCUMENT("Document"),
    HIDDEN_MARKER("Marker"),
    OTHER("Other")
}

enum class DetectedFormat(
    val label: String,
    val category: MediaCategory,
    val canonicalExtensions: Set<String>,
    val mimeType: String
) {
    MP4("MP4", MediaCategory.VIDEO, setOf("mp4", "m4v", "3gp"), "video/mp4"),
    MOV("MOV", MediaCategory.VIDEO, setOf("mov", "qt"), "video/quicktime"),
    MKV("MKV", MediaCategory.VIDEO, setOf("mkv"), "video/x-matroska"),
    WEBM("WEBM", MediaCategory.VIDEO, setOf("webm"), "video/webm"),
    AVI("AVI", MediaCategory.VIDEO, setOf("avi"), "video/x-msvideo"),
    JPG("JPG", MediaCategory.IMAGE, setOf("jpg", "jpeg", "jpe"), "image/jpeg"),
    PNG("PNG", MediaCategory.IMAGE, setOf("png"), "image/png"),
    WEBP("WEBP", MediaCategory.IMAGE, setOf("webp"), "image/webp"),
    GIF("GIF", MediaCategory.IMAGE, setOf("gif"), "image/gif"),
    HEIC("HEIC", MediaCategory.IMAGE, setOf("heic", "heif"), "image/heic"),
    MP3("MP3", MediaCategory.AUDIO, setOf("mp3"), "audio/mpeg"),
    FLAC("FLAC", MediaCategory.AUDIO, setOf("flac"), "audio/flac"),
    OGG("OGG", MediaCategory.AUDIO, setOf("ogg", "oga", "opus"), "audio/ogg"),
    WAV("WAV", MediaCategory.AUDIO, setOf("wav"), "audio/wav"),
    M4A("M4A", MediaCategory.AUDIO, setOf("m4a", "aac"), "audio/mp4"),
    APK("APK", MediaCategory.APK, setOf("apk"), "application/vnd.android.package-archive"),
    ZIP("ZIP", MediaCategory.ARCHIVE, setOf("zip", "jar", "docx", "xlsx"), "application/zip"),
    RAR("RAR", MediaCategory.ARCHIVE, setOf("rar"), "application/vnd.rar"),
    SEVEN_Z("7Z", MediaCategory.ARCHIVE, setOf("7z"), "application/x-7z-compressed"),
    PDF("PDF", MediaCategory.DOCUMENT, setOf("pdf"), "application/pdf"),
    NOMEDIA("NOMEDIA", MediaCategory.HIDDEN_MARKER, setOf("nomedia"), "application/octet-stream"),
    UNKNOWN("OTHER", MediaCategory.OTHER, emptySet(), "application/octet-stream")
}

data class ScannedFileItem(
    val id: String,
    val name: String,
    val path: String,
    val uriString: String? = null,
    val sizeBytes: Long,
    val lastModifiedMs: Long,
    val isHiddenDotFile: Boolean,
    val isInsideHiddenFolder: Boolean,
    val declaredExtension: String,
    val detectedFormat: DetectedFormat,
    val isObfuscatedExtension: Boolean,
    val magicHeaderHex: String = "",
    val durationMs: Long? = null
) {
    val isHidden: Boolean
        get() = isHiddenDotFile || isInsideHiddenFolder

    val category: MediaCategory
        get() = detectedFormat.category
}

data class FormatBreakdown(
    val format: DetectedFormat,
    val count: Int,
    val totalBytes: Long
)

data class DeletionResult(
    val deletedCount: Int,
    val failedCount: Int,
    val freedBytes: Long,
    val deletedIds: Set<String>
)

sealed interface ScanProgressState {
    data object Idle : ScanProgressState

    data class Scanning(
        val scannedFilesCount: Int,
        val scannedBytes: Long,
        val hiddenFilesCount: Int,
        val obfuscatedCount: Int,
        val currentDirectory: String
    ) : ScanProgressState

    data class Completed(
        val files: List<ScannedFileItem>,
        val totalBytes: Long,
        val hiddenCount: Int,
        val obfuscatedCount: Int,
        val formatBreakdowns: List<FormatBreakdown>,
        val durationMs: Long
    ) : ScanProgressState

    data class Error(val message: String) : ScanProgressState
}
