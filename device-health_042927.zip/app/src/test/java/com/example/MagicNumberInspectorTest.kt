package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.scanner.MagicNumberInspector
import com.example.domain.model.DetectedFormat
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class MagicNumberInspectorTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private val context: Context
        get() = ApplicationProvider.getApplicationContext()

    @Test
    fun `detects obfuscated JPEG inside dotfile with bin extension`() {
        val inspector = MagicNumberInspector(context)
        val hiddenJpg = File(tempFolder.root, ".thumb_cache_91.bin")
        hiddenJpg.writeBytes(
            byteArrayOf(
                0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 0xE0.toByte(),
                0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01
            )
        )

        val result = inspector.inspectFile(hiddenJpg)
        assertEquals(DetectedFormat.JPG, result.detectedFormat)
        assertTrue(result.isObfuscatedExtension)
        assertEquals("bin", result.declaredExtension)
    }

    @Test
    fun `detects extensionless MP4 via ftyp header`() {
        val inspector = MagicNumberInspector(context)
        val noExtVideo = File(tempFolder.root, ".hidden_clip")
        noExtVideo.writeBytes(
            byteArrayOf(
                0x00, 0x00, 0x00, 0x18,
                'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte(),
                'm'.code.toByte(), 'p'.code.toByte(), '4'.code.toByte(), '2'.code.toByte()
            )
        )

        val result = inspector.inspectFile(noExtVideo)
        assertEquals(DetectedFormat.MP4, result.detectedFormat)
        assertTrue(result.isObfuscatedExtension)
        assertEquals("", result.declaredExtension)
    }

    @Test
    fun `detects MKV vs WEBM from EBML header`() {
        val inspector = MagicNumberInspector(context)
        val mkvFile = File(tempFolder.root, "sample.mkv")
        mkvFile.writeBytes(
            byteArrayOf(0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte()) + "matroska".toByteArray()
        )
        val webmFile = File(tempFolder.root, "clip.tmp")
        webmFile.writeBytes(
            byteArrayOf(0x1A, 0x45, 0xDF.toByte(), 0xA3.toByte()) + "webm".toByteArray()
        )

        val mkvResult = inspector.inspectFile(mkvFile)
        assertEquals(DetectedFormat.MKV, mkvResult.detectedFormat)
        assertFalse(mkvResult.isObfuscatedExtension)

        val webmResult = inspector.inspectFile(webmFile)
        assertEquals(DetectedFormat.WEBM, webmResult.detectedFormat)
        assertTrue(webmResult.isObfuscatedExtension)
    }

    @Test
    fun `distinguishes disguised APK from regular ZIP`() {
        val inspector = MagicNumberInspector(context)
        val disguisedApk = File(tempFolder.root, ".installer_payload.dat")
        ZipOutputStream(disguisedApk.outputStream()).use { zos ->
            zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
            zos.write(byteArrayOf(0x03, 0x00, 0x08, 0x00))
            zos.closeEntry()
        }

        val regularZip = File(tempFolder.root, "backup.zip")
        ZipOutputStream(regularZip.outputStream()).use { zos ->
            zos.putNextEntry(ZipEntry("notes.txt"))
            zos.write("hello".toByteArray())
            zos.closeEntry()
        }

        val apkResult = inspector.inspectFile(disguisedApk)
        assertEquals(DetectedFormat.APK, apkResult.detectedFormat)
        assertTrue(apkResult.isObfuscatedExtension)

        val zipResult = inspector.inspectFile(regularZip)
        assertEquals(DetectedFormat.ZIP, zipResult.detectedFormat)
        assertFalse(zipResult.isObfuscatedExtension)
    }

    @Test
    fun `identifies nomedia marker`() {
        val inspector = MagicNumberInspector(context)
        val nomedia = File(tempFolder.root, ".nomedia")
        nomedia.createNewFile()

        val result = inspector.inspectFile(nomedia)
        assertEquals(DetectedFormat.NOMEDIA, result.detectedFormat)
        assertFalse(result.isObfuscatedExtension)
    }
}
